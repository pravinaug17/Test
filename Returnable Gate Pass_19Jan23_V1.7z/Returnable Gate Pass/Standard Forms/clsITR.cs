using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using System.Linq;
using RGatePass.Classes;
using RGatePass.Extensions;
using RGatePass.Custom_Forms;

namespace RGatePass.Standard_Forms
{
    class clsITR : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "OWTQ";
        public const string rowTable = "WTQ1";
        public const string formTypeEx = "1250000940";
        public const string objType = "1250000001";
        public const string matrixUID = "23";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                            {
                                oMatrix = oForm.Items.Item(matrixUID).Specific;
                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    try
                                    {
                                        //string baseType = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseType", i)).String;
                                        //if (baseType == objType)
                                        //{
                                        //    string qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i)).String;
                                        //    string baseQty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseQty", i)).String;
                                        //    double dblQty = qty == string.Empty ? 0 : double.Parse(qty);
                                        //    double dblBaseQty = baseQty == string.Empty ? 0 : double.Parse(baseQty);
                                        //    if (dblQty > dblBaseQty)
                                        //    {
                                        //        BubbleEvent = false;
                                        //        oApplication.StatusBar.SetText("Quantity should be less than or equal to Base quantity");
                                        //        return;
                                        //    }
                                        //}
                                    }
                                    catch { }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (pVal.EventType == BoEventTypes.et_FORM_LOAD)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.Item oItem;
                        SAPbouiCOM.Item xItem;
                        SAPbouiCOM.Button oButton;
                        xItem = oForm.Items.Item("2");
                        oItem = oForm.Items.Add("btPO", SAPbouiCOM.BoFormItemTypes.it_BUTTON);

                        oItem.Left = xItem.Left + xItem.Width + 2;
                        oItem.Top = xItem.Top;

                        oItem.Width = oItem.Width + oItem.Width + oItem.Width;
                        oItem.Height = xItem.Height;

                        oButton = (SAPbouiCOM.Button)(oItem.Specific);
                        oButton.Caption = "Copy From PO";
                        oForm.Items.Item("btPO").EnableinAddMode();
                    }
                    else if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "btPO")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (oForm.Mode != BoFormMode.fm_ADD_MODE)
                            {
                                oApplication.StatusBar.SetText("Form should be in Add Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            string whscode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("ToWhsCode", 0).Trim();
                            clsVariables.BaseForm = oForm;
                            clsCopyPO doc = new clsCopyPO();
                            doc.LoadForm(clsCopyPO.formMenuUID, whscode);
                            oForm = oApplication.Forms.ActiveForm;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();


                        sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE T0");
                        sbQuery.Append(" SET T0.\"U_OpenQty\" =  T0.\"Quantity\" ");
                        sbQuery.Append(" FROM \"" + rowTable + "\" T0");
                        sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + docEntry + "'  ");
                        objclsCommon.SelectRecord(sbQuery.ToString());


                        sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE T0");
                        sbQuery.Append(" SET T0.\"U_OpenQty\" =  T0.\"PlannedQty\" ");
                        sbQuery.Append(" FROM \"" + CommonTables.ProductionOrderRowTable + "\" T0");
                        sbQuery.Append(" INNER JOIN " + rowTable + " T1 ON T0.\"LineNum\" = T1.\"U_BaseLi\" AND T0.\"DocEntry\" = T1.\"U_BaseEntry\" AND T1.\"U_BaseType\"= '202'  ");
                        sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "'  ");
                        sbQuery.Append(" AND T0.\"U_OpenQty\" IS NULL ");
                        objclsCommon.SelectRecord(sbQuery.ToString());

                        sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE T0");
                        sbQuery.Append(" SET T0.\"U_OpenQty\" = T0.\"U_OpenQty\" - T1.\"Quantity\" ");
                        sbQuery.Append(" FROM \"" + CommonTables.ProductionOrderRowTable + "\" T0");
                        sbQuery.Append(" INNER JOIN " + rowTable + " T1 ON T0.\"LineNum\" = T1.\"U_BaseLi\" AND T0.\"DocEntry\" = T1.\"U_BaseEntry\" AND T1.\"U_BaseType\"= '202'  ");
                        sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "'  ");
                        objclsCommon.SelectRecord(sbQuery.ToString());

                        //sbQuery = new StringBuilder();
                        //sbQuery.Append(" UPDATE T0");
                        //sbQuery.Append(" SET T0.\"U_LineStat\" = 'C'  ");
                        //sbQuery.Append(" FROM \"" + clsDepartmentalIssue.rowTable + "\" T0");
                        //sbQuery.Append(" INNER JOIN " + rowTable + " T1 ON T0.\"LineId\" = T1.\"U_BaseLi\" AND T0.\"DocEntry\" = T1.\"U_BaseEntry\" AND T0.\"Object\" = T1.\"U_BaseType\"  ");
                        //sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "' AND T0.\"U_OpenQty\" = 0  ");
                        //objclsCommon.SelectRecord(sbQuery.ToString());

                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion
    }
}
