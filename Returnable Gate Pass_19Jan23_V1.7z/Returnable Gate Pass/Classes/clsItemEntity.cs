﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGatePass.Classes
{
    public class clsItemEntity
    {
        public int DocEntry { get; set; }
        public int DocNum { get; set; }
        public int LineId { get; set; }

        public string ItemCode { get; set; }

        public string ItemName { get; set; }

        public string WhsCode { get; set; }

        public string LotNo { get; set; }
        public string Price { get; set; }

        public string BoxNo { get; set; }

        public string TakaNo { get; set; }
        public string TareWeight { get; set; }

        public string NetWeight { get; set; }

        public string Qty { get; set; }

        public string Batch { get; set; }
        public string Project { get; set; }
        public string Dim1 { get; set; }
        public string Dim2 { get; set; }
        public string Dim3 { get; set; }
        public string Dim4 { get; set; }
        public string Dim5 { get; set; }
    }
}
