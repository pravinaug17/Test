using RGatePass;
using RGatePass.Classes;
using RGatePass.Extensions;
using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using SAPbouiCOM;
using System;
using System.Reflection;
using RGatePass.Custom_Forms;
using RGatePass.Standard_Forms;

namespace RGatePass.Classes
{
    class SAPMain : Connection
    {
        public static ILog logger;

        #region Variables
        clsCommon _clsCommon = new clsCommon();

        // Custom Forms
        clsRGatePassOut _clsRGatePassOut = new clsRGatePassOut();
        clsRGatePassIn _clsRGatePassIn = new clsRGatePassIn();
        clsNonRGatePass _clsNonRGatePass = new clsNonRGatePass();
        clsDepartmentalIssue _clsDepartmentalIssue = new clsDepartmentalIssue();
        clsContractorMaterialReceipt _clsContractorMaterialReceipt = new clsContractorMaterialReceipt();
        clsContractorMaterialReturn _clsContractorMaterialReturn = new clsContractorMaterialReturn();
        clsCopyITR _clsCopyITR = new clsCopyITR();
        clsCopyCMR _clsCopyCMR = new clsCopyCMR();
        clsCopyRGatePassOut _clsCopyRGatePassOut = new clsCopyRGatePassOut();
        clsCopyDepartmentalIssue _clsCopyDepartmentalIssue = new clsCopyDepartmentalIssue();
        clsBatchSelection _clsBatchSelection = new clsBatchSelection();
        clsBatchIn _clsBatchIn = new clsBatchIn();
        clsCopyPO _clsCopyPO = new clsCopyPO();
        //Standard Forms
        clsGoodsIssue _clsGoodsIssue = new clsGoodsIssue();
        clsITR _clsITR = new clsITR();

        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();
            PrepareMenus();
            PrepareEvents();
        }

        private void PrepareMenus()
        {
            RemoveMenusFromSAP();

            // 8192 - System Initialisation
            // 43520 - Main Menu
            _clsCommon.AddMenu(BoMenuType.mt_STRING, "8192", "RUDO", "Create Returable UDO", 0);
            string menuCode = "";
            string isActive = "";
            menuCode = "RGPO";
            isActive = _clsCommon.IsMenuActive(menuCode);
            int position = 5;
            if (isActive == "Y")
            {
                _clsCommon.AddMenu(BoMenuType.mt_STRING, "43540", menuCode, "Returnable Gate Pass Out", position);
                position = position + 1;
            }
            menuCode = "RGPI";
            isActive = _clsCommon.IsMenuActive(menuCode);
            if (isActive == "Y")
            {
                _clsCommon.AddMenu(BoMenuType.mt_STRING, "43540", menuCode, "Returnable Gate Pass In", position);
                position = position + 1;
            }
            menuCode = "NRGP";
            isActive = _clsCommon.IsMenuActive(menuCode);
            if (isActive == "Y")
            {
                _clsCommon.AddMenu(BoMenuType.mt_STRING, "43540", menuCode, "Non Returnable Gate Pass", position);
                position = position + 1;
            }
            menuCode = "DMIR";
            isActive = _clsCommon.IsMenuActive(menuCode);
            if (isActive == "Y")
            {
                _clsCommon.AddMenu(BoMenuType.mt_STRING, "43540", menuCode, "Departmental Material Issue Request", position);
                position = position + 1;
            }
            menuCode = "CMR";
            isActive = _clsCommon.IsMenuActive(menuCode);
            if (isActive == "Y")
            {
                _clsCommon.AddMenu(BoMenuType.mt_STRING, "43540", menuCode, "Contractor�s Material Receipt", position);
                position = position + 1;
            }
            menuCode = "CMRT";
            isActive = _clsCommon.IsMenuActive(menuCode);
            if (isActive == "Y")
            {
                _clsCommon.AddMenu(BoMenuType.mt_STRING, "43540", menuCode, "Contractor�s Material Return", position);
                position = position + 1;
            }
        }

        private void RemoveMenusFromSAP()
        {
            _clsCommon.RemoveMenu("RUDO");
            _clsCommon.RemoveMenu("RGPO");
            _clsCommon.RemoveMenu("RGPI");
            _clsCommon.RemoveMenu("NRGP");
            _clsCommon.RemoveMenu("DMIR");
            _clsCommon.RemoveMenu("CMR");
            _clsCommon.RemoveMenu("CMRT");
        }

        /// <summary>
        /// Create Event Handler 
        /// </summary>
        private void PrepareEvents()
        {
            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
            oApplication.LayoutKeyEvent += new _IApplicationEvents_LayoutKeyEventEventHandler(oApplication_LayoutKeyEvent);
        }


        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.FormTypeEx == clsRGatePassOut.formTypeEx)
                {
                    _clsRGatePassOut.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsRGatePassIn.formTypeEx)
                {
                    _clsRGatePassIn.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsNonRGatePass.formTypeEx)
                {
                    _clsNonRGatePass.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsDepartmentalIssue.formTypeEx)
                {
                    _clsDepartmentalIssue.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsContractorMaterialReceipt.formTypeEx)
                {
                    _clsContractorMaterialReceipt.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsContractorMaterialReturn.formTypeEx)
                {
                    _clsContractorMaterialReturn.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsGoodsIssue.formTypeEx)
                {
                    _clsGoodsIssue.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsITR.formTypeEx)
                {
                    _clsITR.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsCopyITR.formTypeEx)
                {
                    _clsCopyITR.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsCopyCMR.formTypeEx)
                {
                    _clsCopyCMR.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsCopyRGatePassOut.formTypeEx)
                {
                    _clsCopyRGatePassOut.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsCopyDepartmentalIssue.formTypeEx)
                {
                    _clsCopyDepartmentalIssue.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsBatchSelection.formTypeEx)
                {
                    _clsBatchSelection.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsBatchIn.formTypeEx)
                {
                    _clsBatchIn.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsCopyPO.formTypeEx)
                {
                    _clsCopyPO.ItemEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            SAPbouiCOM.Form oForm = null;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }

                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == "RUDO")
                    {
                        oApplication.StatusBar.SetText("Please wait....", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        _clsCommon.CreateDataBase();
                        oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    }
                }

                if (pVal.MenuUID == clsRGatePassOut.formMenuUID || (oForm != null && oForm.TypeEx == clsRGatePassOut.formMenuUID))
                {
                    _clsRGatePassOut.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == clsRGatePassIn.formMenuUID || (oForm != null && oForm.TypeEx == clsRGatePassIn.formMenuUID))
                {
                    _clsRGatePassIn.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == clsNonRGatePass.formMenuUID || (oForm != null && oForm.TypeEx == clsNonRGatePass.formMenuUID))
                {
                    _clsNonRGatePass.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == clsDepartmentalIssue.formMenuUID || (oForm != null && oForm.TypeEx == clsDepartmentalIssue.formMenuUID))
                {
                    _clsDepartmentalIssue.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == clsContractorMaterialReceipt.formMenuUID || (oForm != null && oForm.TypeEx == clsContractorMaterialReceipt.formMenuUID))
                {
                    _clsContractorMaterialReceipt.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == clsContractorMaterialReturn.formMenuUID || (oForm != null && oForm.TypeEx == clsContractorMaterialReturn.formMenuUID))
                {
                    _clsContractorMaterialReturn.MenuEvent(ref pVal, out BubbleEvent);
                }
                if ((oForm != null && oForm.TypeEx == clsBatchIn.formMenuUID))
                {
                    _clsBatchIn.MenuEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.FormTypeEx == clsRGatePassOut.formTypeEx)
                {
                    _clsRGatePassOut.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == clsRGatePassIn.formTypeEx)
                {
                    _clsRGatePassIn.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == clsNonRGatePass.formTypeEx)
                {
                    _clsNonRGatePass.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == clsDepartmentalIssue.formTypeEx)
                {
                    _clsDepartmentalIssue.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == clsContractorMaterialReceipt.formTypeEx)
                {
                    _clsContractorMaterialReceipt.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == clsContractorMaterialReturn.formTypeEx)
                {
                    _clsContractorMaterialReturn.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == clsGoodsIssue.formTypeEx)
                {
                    _clsGoodsIssue.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == clsITR.formTypeEx)
                {
                    _clsITR.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany);
                    RemoveMenusFromSAP();
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Company changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Server Terminition Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Language changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
            }
        }

        void oApplication_LayoutKeyEvent(ref LayoutKeyInfo eventInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (eventInfo.BeforeAction == true)
            {
                if (eventInfo.FormUID.Contains(clsRGatePassOut.formMenuUID)
                    || eventInfo.FormUID.Contains(clsRGatePassIn.formMenuUID)
                    || eventInfo.FormUID.Contains(clsNonRGatePass.formMenuUID)
                   || eventInfo.FormUID.Contains(clsDepartmentalIssue.formMenuUID)
                   || eventInfo.FormUID.Contains(clsContractorMaterialReceipt.formMenuUID)
                   || eventInfo.FormUID.Contains(clsContractorMaterialReturn.formMenuUID)
                   
                   )
                {
                    eventInfo.LayoutKey = clsVariables.DocEntry;
                }
            }
        }
        #endregion

        #region Methods

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion
    }
}
