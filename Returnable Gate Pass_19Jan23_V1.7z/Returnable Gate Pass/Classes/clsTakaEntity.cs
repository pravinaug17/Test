﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGatePass.Classes
{
    public class clsTakaEntity
    {
        public string LotNo { get; set; }
        public string TakaNo { get; set; }
        public string ItemCode { get; set; }

        public string ItemName { get; set; }

        public string BaseDesign { get; set; }

        public string BaseColor { get; set; }
        public string UOM { get; set; }
        public string FGItem { get; set; }
        public string Design { get; set; }
        public string Color { get; set; }
        public string QtyTaka { get; set; }
        public string QtyMtr { get; set; }
    }
}
