﻿namespace RGatePass.Classes
{ 
    public static class CommonTables
    {
        public const string RBatchTable = "@RBATCH";
        public const string UDOSeriesHeaderTable = "@UDOSER";
        public const string UDOSeriesRowTable = "@UDOSER1";
        public const string GatePassTable = "@OGATE";
        public const string ProductionOrderHeaderTable = "OWOR";
        public const string ProductionOrderRowTable = "WOR1";
        public const string ItemMasterTable = "OITM";
    }
}
 