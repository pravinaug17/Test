﻿using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using RGatePass.Classes;

namespace RGatePass.Custom_Forms
{
    class clsCopyRGatePassOut : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Folder oFolder;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formTypeEx = "COPYRGPO";
        public const string formMenuUID = "COPYRGPO";
        const string formTitle = "Copy From RGPO";
        const string gridDocumentsUID = "grd1";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "btCopy")
                            {
                                SAPbouiCOM.DataTable dataTable = oForm.DataSources.DataTables.Item(gridDocumentsUID);
                                List<clsItemEntity> _clsItemEntityList = new List<clsItemEntity>();
                                for (int i = 0; i < dataTable.Rows.Count; i++)
                                {
                                    if (dataTable.GetValue("Selection", i) == "Y")
                                    {
                                        clsItemEntity _clsItemEntity = new clsItemEntity();

                                        _clsItemEntity.LineId = dataTable.GetValue("LineId", i);
                                        _clsItemEntity.DocEntry = dataTable.GetValue("DocEntry", i);
                                        _clsItemEntity.DocNum = dataTable.GetValue("DocNum", i);
                                        _clsItemEntityList.Add(_clsItemEntity);
                                    }
                                }
                                if (_clsItemEntityList.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("Please select row", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                oForm.Items.Item("2").Click(BoCellClickType.ct_Regular);

                                SAPbouiCOM.Form oBaseForm = clsVariables.BaseForm;
                                string randomNo = oBaseForm.DataSources.DBDataSources.Item(clsRGatePassIn.headerTable).GetValue(clsRGatePassIn.randomUDF, 0);
                                oApplication.StatusBar.SetText("Please wait ....", BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);

                                #region Row 
                                SAPbouiCOM.Matrix oBaseMatrix = oBaseForm.Items.Item(clsRGatePassIn.matrixUID).Specific;
                                oBaseMatrix.Clear();
                                oDbDataSource = oBaseForm.DataSources.DBDataSources.Item(clsRGatePassIn.rowTable);
                                int rowNo = 0;
                                oBaseMatrix.FlushToDataSource();
                                for (int i = 0; i < _clsItemEntityList.Count; i++)
                                {
                                    int lineId = _clsItemEntityList[i].LineId;
                                    int docEntry = _clsItemEntityList[i].DocEntry;
                                    int docNum = _clsItemEntityList[i].DocNum;

                                    sbQuery = new StringBuilder();
                                    sbQuery.Append(" SELECT \"U_ITEn\" FROM  ");
                                    sbQuery.Append(" \"" + clsRGatePassOut.headerTable + "\" T1");
                                    sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "'  ");

                                    string itDocEntry = objclsCommon.SelectRecord(sbQuery.ToString());

                                    sbQuery = new StringBuilder();
                                    sbQuery.Append(" SELECT * FROM  ");
                                    sbQuery.Append(" \"" + clsRGatePassOut.rowTable + "\" T1");
                                    sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + docEntry + "' AND T1.\"LineId\" ='" + lineId + "' ");
                                    oRs = objclsCommon.returnRecord(sbQuery.ToString());

                                    if (!oRs.EoF)
                                    {
                                        oDbDataSource.InsertRecord(rowNo);
                                        oDbDataSource.SetValue("LineId", rowNo, Convert.ToString(rowNo + 1));
                                        string itemcode = oRs.Fields.Item("U_ItemCode").Value;
                                        string selQty = oRs.Fields.Item("U_OpenQty").Value.ToString();
                                        oDbDataSource.SetValue("U_ItemCode", rowNo, oRs.Fields.Item("U_ItemCode").Value);
                                        oDbDataSource.SetValue("U_ItemName", rowNo, oRs.Fields.Item("U_ItemName").Value);
                                        oDbDataSource.SetValue("U_Qty", rowNo, selQty);
                                        oDbDataSource.SetValue("U_InvUOM", rowNo, oRs.Fields.Item("U_InvUOM").Value);
                                        oDbDataSource.SetValue("U_FrWhs", rowNo, oRs.Fields.Item("U_ToWhs").Value);
                                        oDbDataSource.SetValue("U_ToWhs", rowNo, oRs.Fields.Item("U_FrWhs").Value);
                                        string whscode = oRs.Fields.Item("U_FrWhs").Value;
                                        string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(oRs.Fields.Item("U_ItemCode").Value, oRs.Fields.Item("U_ToWhs").Value));
                                        oDbDataSource.SetValue("U_StkInWhs", rowNo, stock);
                                        oDbDataSource.SetValue("U_WQtyPost", rowNo, oRs.Fields.Item("U_WQtyPost").Value);
                                        oDbDataSource.SetValue("U_InfoPri", rowNo, oRs.Fields.Item("U_InfoPri").Value);
                                        oDbDataSource.SetValue("U_Purpose", rowNo, oRs.Fields.Item("U_Purpose").Value);
                                        oDbDataSource.SetValue("U_Project", rowNo, oRs.Fields.Item("U_Project").Value);
                                        oDbDataSource.SetValue("U_Remark", rowNo, oRs.Fields.Item("U_Remark").Value);

                                        oDbDataSource.SetValue("U_Pertic", rowNo, oRs.Fields.Item("U_Pertic").Value);
                                        oDbDataSource.SetValue("U_IssueF", rowNo, oRs.Fields.Item("U_IssueF").Value);
                                        oDbDataSource.SetValue("U_CostCent", rowNo, oRs.Fields.Item("U_CostCent").Value);

                                        oDbDataSource.SetValue("U_Dim1", rowNo, oRs.Fields.Item("U_Dim1").Value);
                                        oDbDataSource.SetValue("U_Dim2", rowNo, oRs.Fields.Item("U_Dim2").Value);
                                        oDbDataSource.SetValue("U_Dim3", rowNo, oRs.Fields.Item("U_Dim3").Value);
                                        oDbDataSource.SetValue("U_Dim4", rowNo, oRs.Fields.Item("U_Dim4").Value);
                                        oDbDataSource.SetValue("U_Dim5", rowNo, oRs.Fields.Item("U_Dim5").Value);

                                        oDbDataSource.SetValue("U_BaseEntry", rowNo, docEntry.ToString());
                                        oDbDataSource.SetValue("U_BaseType", rowNo, clsRGatePassOut.objType);
                                        oDbDataSource.SetValue("U_BaseLine", rowNo, lineId.ToString());
                                        oDbDataSource.SetValue("U_BaseQty", rowNo, selQty);
                                        //InsertInRBatch(itDocEntry, lineId.ToString(), whscode, itemcode, selQty, randomNo);

                                        //string itemcode = oRs.Fields.Item("ItemCode").Value;
                                        //string defaultWhs = oRs.Fields.Item("WhsCode").Value;
                                        //string instock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode));
                                        //oDbDataSource.SetValue("U_InStock", rowNo, instock);
                                        //string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, defaultWhs));
                                        //oDbDataSource.SetValue("U_QtyWhs", rowNo, stock);
                                        rowNo++;
                                    }

                                }
                                oBaseMatrix.LoadFromDataSource();

                                #endregion

                                oApplication.StatusBar.SetText("Data loaded", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);

                            }


                            else if (pVal.ItemUID == "btSelAll")
                            {
                                SAPbouiCOM.DataTable dataTable = oForm.DataSources.DataTables.Item(gridDocumentsUID);
                                List<string> list = new List<string>();
                                for (int i = 0; i < dataTable.Rows.Count; i++)
                                {
                                    string chk = dataTable.GetValue("Selection", i);
                                    if (chk == "Y")
                                    {
                                        list.Add(dataTable.GetValue("DocEntry", i).ToString());
                                    }
                                }
                                string sodocentry = String.Join(",", list);
                                FillGrid("Y");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "btCopyFrom")
                            {

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID, "");
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm(string menuID, string cardcode)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    //objclsCommon.LoadForm()
                    //objclsCommon.LoadXML(menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
                    oForm = objclsCommon.LoadForm_Modal(menuID, menuID, BoFormModality.fm_Modal);
                    try
                    {
                        oForm = oApplication.Forms.ActiveForm;
                    }
                    catch
                    {
                        oForm = oApplication.Forms.GetForm(menuID, 0);
                    }
                    oForm.DataSources.UserDataSources.Add("CardCode", BoDataType.dt_LONG_TEXT, 50);
                    oForm.DataSources.UserDataSources.Item("CardCode").ValueEx = cardcode;
                    FillGrid("N");
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void FillGrid(string selection)
        {
            try
            {
                oForm = oApplication.Forms.ActiveForm;
                string cardcode = oForm.DataSources.UserDataSources.Item("CardCode").ValueEx;
                sbQuery.Length = 0;
                if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                {
                    //sbQuery.Append("call Proc_SalesAgr_CopyFromSQ_Documents ('" + cardcode + "')");
                }
                else
                {
                }

                sbQuery.Length = 0;
                sbQuery.Append(" SELECT '" + selection + "' as \"Selection\" ,  T0.\"DocNum\", T1.\"LineId\", T1.\"U_ItemCode\" as \"ItemCode\" ");
                sbQuery.Append(" ,T1.\"U_ItemName\" as \"ItemName\", T1.\"U_OpenQty\" \"Quantity\",T0.\"DocEntry\",T1.\"U_GateEn\" \"Gate Entry\"  ");
                sbQuery.Append(" FROM \"" + clsRGatePassOut.headerTable + "\" T0 ");
                sbQuery.Append(" INNER JOIN \"" + clsRGatePassOut.rowTable + "\" T1 ON T0.\"DocEntry\"= T1.\"DocEntry\" ");
                sbQuery.Append(" WHERE T1.\"U_OpenQty\" > 0");
                sbQuery.Append(" AND T0.\"U_CardCode\" ='" + cardcode + "'");
                //if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                //{
                //    sbQuery.Append(" AND IFNULL(T0.\"U_ITEn\",'') !='' ");
                //}
                //else
                //{
                //    sbQuery.Append(" AND ISNULL(T0.\"U_ITEn\",'') !='' ");
                //}

                objclsCommon.FillGrid(oForm.UniqueID, gridDocumentsUID, gridDocumentsUID, sbQuery.ToString());
                SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridDocumentsUID).Specific;
                for (int i = 1; i < oGrid.Columns.Count; i++)
                {
                    oGrid.Columns.Item(i).Editable = false;
                    oGrid.Columns.Item(i).TitleObject.Sortable = true;
                }
                oGrid.Columns.Item(0).Type = BoGridColumnType.gct_CheckBox;
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("FillGrid:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void InsertInRBatch(string itDocEntry, string lineId, string whscode, string itemcode, string selQty, string randomNo)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("DELETE FROM \"@RBATCH\" WHERE \"U_BaseEn\" = '" + randomNo + "' AND \"U_LineId\" = '" + lineId + "' ");
            objclsCommon.SelectRecord(sbQuery.ToString());
            sbQuery = new StringBuilder();
            SAPbobsCOM.Recordset oRsBatch = objclsCommon.returnRecord(objclsCommon.GetBatchWithLineId(itDocEntry, lineId, whscode, "67"));
            while (!oRsBatch.EoF)
            {
                string batch = oRsBatch.Fields.Item(0).Value;
                string todayDate = DateTime.Now.ToString("yyyyMMdd");
                string code = objclsCommon.SelectRecord("SELECT MAX(Cast(\"Code\" AS NUMERIC(19,0))) FROM \"@RBATCH\" ");
                code = code == string.Empty ? "0" : code;
                Int32 iCode = Int32.Parse(code) + 1;
                sbQuery = new StringBuilder();
                sbQuery.Append("INSERT INTO \"@RBATCH\"(\"Code\",\"Name\",\"U_LineId\",\"U_ItemCode\",\"U_WhsCode\",\"U_BatchNo\",\"U_Qty\",\"U_BaseEn\",\"U_Date\") ");
                sbQuery.Append("VALUES('" + iCode.ToString() + "','" + iCode.ToString() + "','" + lineId + "','" + itemcode + "','" + whscode + "','" + batch + "','" + selQty + "','" + randomNo + "','" + todayDate + "' ) ");
                objclsCommon.SelectRecord(sbQuery.ToString());
                oRsBatch.MoveNext();
            }
        }
    }
}
