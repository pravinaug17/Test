﻿using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using RGatePass.Classes;
using RGatePass.Standard_Forms;

namespace RGatePass.Custom_Forms
{
    class clsCopyDepartmentalIssue : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Folder oFolder;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formTypeEx = "CPDMIR";
        public const string formMenuUID = "CPDMIR";
        const string formTitle = "Copy Material Request";
        const string gridDocumentsUID = "grdDI";
        DateTime minDate = new DateTime(2000, 01, 01);

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "btCopy")
                            {
                                SAPbouiCOM.DataTable dataTable = oForm.DataSources.DataTables.Item(gridDocumentsUID);
                                List<clsItemEntity> _clsItemEntityList = new List<clsItemEntity>();
                                for (int i = 0; i < dataTable.Rows.Count; i++)
                                {
                                    if (dataTable.GetValue("Selection", i) == "Y")
                                    {
                                        clsItemEntity _clsItemEntity = new clsItemEntity();

                                        _clsItemEntity.LineId = dataTable.GetValue("LineId", i);
                                        _clsItemEntity.DocEntry = dataTable.GetValue("DocEntry", i);
                                        _clsItemEntity.DocNum = dataTable.GetValue("DocNum", i);
                                        _clsItemEntityList.Add(_clsItemEntity);
                                    }
                                }
                                if (_clsItemEntityList.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("Please select row", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                oForm.Items.Item("2").Click(BoCellClickType.ct_Regular);

                                SAPbouiCOM.Form oBaseForm = clsVariables.BaseForm;
                                oMatrix = oBaseForm.Items.Item(clsGoodsIssue.matrixUID).Specific;
                                int rowNo = 1;
                                for (int i = 0; i < _clsItemEntityList.Count; i++)
                                {
                                    int lineId = _clsItemEntityList[i].LineId;
                                    int docEntry = _clsItemEntityList[i].DocEntry;
                                    int docNum = _clsItemEntityList[i].DocNum;
                                    oRs = objclsCommon.returnRecord("SELECT * FROM \"" + clsDepartmentalIssue.rowTable + "\" WHERE \"DocEntry\" = '" + docEntry + "' AND \"LineId\"='" + lineId + "'");
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", rowNo)).String = oRs.Fields.Item("U_ItemCode").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseEntry", rowNo)).String = oRs.Fields.Item("DocEntry").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseType", rowNo)).String = oRs.Fields.Item("Object").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseLi", rowNo)).String = oRs.Fields.Item("LineId").Value.ToString();
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseQty", rowNo)).String = oRs.Fields.Item("U_OpenQty").Value.ToString();

                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", rowNo)).String = oRs.Fields.Item("U_FrWhs").Value.ToString();

                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("21", rowNo)).String = oRs.Fields.Item("U_Project").Value.ToString();
                                    }
                                    catch (Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    }
                                   
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FreeTxt", rowNo)).String = oRs.Fields.Item("U_Purpose").Value.ToString();
                                    }
                                    catch (Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10", rowNo)).String = oRs.Fields.Item("U_InfoPri").Value.ToString();
                                    }
                                    catch (Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Remarks", rowNo)).String = oRs.Fields.Item("U_Remark").Value.ToString();
                                    }
                                    catch (Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Purpose", rowNo)).String = oRs.Fields.Item("U_Purpose").Value.ToString();
                                    }
                                    catch (Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    }
                                    try
                                    {
                                        //((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Purchasefor", rowNo)).String = oRs.Fields.Item("U_Purchasefor").Value.ToString();
                                        ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_Purchasefor", rowNo)).Select(oRs.Fields.Item("U_IssueF").Value.ToString(), BoSearchKey.psk_ByValue);
                                    }
                                    catch (Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_Cost_Center", rowNo)).Select(oRs.Fields.Item("U_CostCent").Value.ToString(),BoSearchKey.psk_ByValue);
                                    }
                                    catch(Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    }
                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("9", rowNo)).String = oRs.Fields.Item("U_OpenQty").Value.ToString();
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10001004", rowNo)).String = oRs.Fields.Item("U_Dim1").Value.ToString();
                                    }
                                    catch (Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    }
                                    try
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10001010", rowNo)).String = oRs.Fields.Item("U_Dim2").Value.ToString();
                                    }
                                    catch (Exception ex)
                                    {
                                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                                    }
                                    rowNo++;
                                }
                            }
                            else if (pVal.ItemUID == "btSelAll")
                            {
                                FillGrid("Y");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "btCopyFrom")
                            {

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm(string menuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    //oForm = objclsCommon.LoadXML(menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
                    oForm = objclsCommon.LoadForm_Modal(menuID, menuID, BoFormModality.fm_Modal);
                    FillGrid("N");
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void FillGrid(string selection)
        {
            oForm = oApplication.Forms.ActiveForm;
            if (oForm.Title.Contains("Material"))
            {

            }
            else
            {
                oForm = oApplication.Forms.GetForm(formTypeEx, 0);
            }
            sbQuery.Length = 0;
            sbQuery.Append(" SELECT '" + selection + "' as \"Selection\" ,  T0.\"DocNum\", T2.\"Name\" \"Department\", T1.\"LineId\", T1.\"U_ItemCode\" as \"ItemCode\" ");
            sbQuery.Append(" ,T1.\"U_ItemName\" as \"ItemName\", T1.\"U_OpenQty\" \"Quantity\", T0.\"U_FrWhs\" \"WhsCode\", T0.\"U_Remark\" \"Remark\",T0.\"DocEntry\"   ");
            sbQuery.Append(" FROM \"" + clsDepartmentalIssue.headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + clsDepartmentalIssue.rowTable + "\" T1 ON T0.\"DocEntry\"= T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN OUDP T2 ON T0.\"U_Dept\"= T2.\"Code\" ");
            sbQuery.Append(" WHERE T1.\"U_OpenQty\" > 0");
            sbQuery.Append(" AND T0.\"Canceled\" ='N' ");
            objclsCommon.FillGrid(oForm.UniqueID, gridDocumentsUID, gridDocumentsUID, sbQuery.ToString());
            SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridDocumentsUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
            oGrid.Columns.Item(0).Type = BoGridColumnType.gct_CheckBox;
        }

    }
}
