﻿using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using RGatePass.Classes;
using RGatePass.Standard_Forms;

namespace RGatePass.Custom_Forms
{
    class clsBatchSelection : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DataTable oDataTable = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formTypeEx = "BATCHSEL";
        public const string formMenuUID = "BATCHSEL";
        const string formTitle = "Batch Selection";
        const string gridDocumentsUID = "grd1";
        const string randomUDF = "U_Random";
        const string baseFormMenuIDUDF = "BaseMenu";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            //Shift to right
                            if (pVal.ItemUID == "18")
                            {
                                string randomNo = oForm.DataSources.UserDataSources.Item(randomUDF).ValueEx;

                                SAPbouiCOM.Matrix oHeaderMatrix = oForm.Items.Item("14").Specific;
                                oHeaderMatrix.FlushToDataSource();
                                SAPbouiCOM.DataTable oDT1 = oForm.DataSources.DataTables.Item("oDT1");
                                int headerSelectedrow = 0;
                                int selectedrow = 0;
                                for (int i = 1; i <= oHeaderMatrix.VisualRowCount; i++)
                                {
                                    try
                                    {
                                        if (oHeaderMatrix.IsRowSelected(i))
                                        {
                                            headerSelectedrow = i - 1;
                                            break;
                                        }
                                    }
                                    catch { }
                                }
                                string itemcode = oDT1.GetValue("ItemCode", headerSelectedrow);
                                string whscode = oDT1.GetValue("WhsCode", headerSelectedrow);
                                string lineId = oDT1.GetValue("LineId", headerSelectedrow);
                                string qty = oDT1.GetValue("Qty", headerSelectedrow);

                                oMatrix = oForm.Items.Item("4").Specific;
                                oMatrix.FlushToDataSource();
                                SAPbouiCOM.DataTable oDT2 = oForm.DataSources.DataTables.Item("oDT2");
                                selectedrow = 0;
                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    try
                                    {
                                        if (oMatrix.IsRowSelected(i))
                                        {
                                            selectedrow = i - 1;
                                            break;
                                        }
                                    }
                                    catch { }
                                }


                                string todayDate = DateTime.Now.ToString("yyyyMMdd");
                                string batch = oDT2.GetValue("DistNumber", selectedrow);

                                double dblRequiredQty = qty == string.Empty ? 0 : double.Parse(qty);
                                string selQty = oDT2.GetValue("SelQty", selectedrow).ToString();
                                double dblSelQty = selQty == string.Empty ? 0 : double.Parse(selQty);
                                if (dblSelQty == 0)
                                {
                                    oApplication.StatusBar.SetText("Selected quantity should be greater than 0 ", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                else if (dblSelQty > dblRequiredQty)
                                {
                                    oApplication.StatusBar.SetText("Selected quantity should be less or equal to required quantity", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                double dblSelectedQty = GetItemQuantity(randomNo, lineId);
                                if (dblSelectedQty == dblRequiredQty)
                                {
                                    oApplication.StatusBar.SetText("Required quantity already selected", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string code = objclsCommon.SelectRecord("SELECT MAX(Cast(\"Code\" AS NUMERIC(19,0))) FROM \"@RBATCH\" ");
                                code = code == string.Empty ? "0" : code;
                                Int32 iCode = Int32.Parse(code) + 1;
                                sbQuery = new StringBuilder();
                                sbQuery.Append("INSERT INTO \"@RBATCH\"(\"Code\",\"Name\",\"U_LineId\",\"U_ItemCode\",\"U_WhsCode\",\"U_BatchNo\",\"U_Qty\",\"U_BaseEn\",\"U_Date\") ");
                                sbQuery.Append("VALUES('" + iCode.ToString() + "','" + iCode.ToString() + "','" + lineId + "','" + itemcode + "','" + whscode + "','" + batch + "','" + selQty + "','" + randomNo + "','" + todayDate + "' ) ");
                                objclsCommon.SelectRecord(sbQuery.ToString());
                                FillAvailableMatrix(itemcode, whscode, randomNo);
                                FillSelectedMatrix(randomNo, lineId);
                                if (oForm.Mode == BoFormMode.fm_UPDATE_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_OK_MODE;
                                }
                                oDT1.SetValue("TotNeed", headerSelectedrow, (dblRequiredQty - dblSelectedQty - dblSelQty).ToString());
                                oHeaderMatrix.LoadFromDataSource();

                                oMatrix = oForm.Items.Item("4").Specific;
                                oMatrix.SelectRow(1, true, false);

                                oMatrix = oForm.Items.Item("15").Specific;
                                oMatrix.SelectRow(1, true, false);
                            }

                            //Shift to left
                            else if (pVal.ItemUID == "19")
                            {
                                string randomNo = oForm.DataSources.UserDataSources.Item(randomUDF).ValueEx;

                                oMatrix = oForm.Items.Item("14").Specific;
                                oMatrix.FlushToDataSource();
                                SAPbouiCOM.DataTable oDT1 = oForm.DataSources.DataTables.Item("oDT1");
                                int selectedrow = 0;
                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    try
                                    {
                                        if (oMatrix.IsRowSelected(i))
                                        {
                                            selectedrow = i - 1;
                                            break;
                                        }
                                    }
                                    catch { }
                                }
                                string itemcode = oDT1.GetValue("ItemCode", selectedrow);
                                string whscode = oDT1.GetValue("WhsCode", selectedrow);
                                string lineId = oDT1.GetValue("LineId", selectedrow);

                                oMatrix = oForm.Items.Item("15").Specific;
                                oMatrix.FlushToDataSource();
                                SAPbouiCOM.DataTable oDT3 = oForm.DataSources.DataTables.Item("oDT3");
                                selectedrow = 0;
                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    try
                                    {
                                        if (oMatrix.IsRowSelected(i))
                                        {
                                            selectedrow = i - 1;
                                            break;
                                        }
                                    }
                                    catch { }
                                }
                                string batchNo = oDT3.GetValue("DistNumber", selectedrow);

                                sbQuery = new StringBuilder();
                                sbQuery.Append("DELETE FROM \"@RBATCH\" WHERE \"U_BaseEn\" = '" + randomNo + "' AND \"U_LineId\" = '" + lineId + "' AND \"U_BatchNo\" = '" + batchNo + "' ");
                                objclsCommon.SelectRecord(sbQuery.ToString());
                                FillAvailableMatrix(itemcode, whscode, randomNo);
                                FillSelectedMatrix(randomNo, lineId);
                                if (oForm.Mode == BoFormMode.fm_UPDATE_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_OK_MODE;
                                }
                                oMatrix = oForm.Items.Item("4").Specific;
                                oMatrix.SelectRow(1, true, false);

                                oMatrix = oForm.Items.Item("15").Specific;
                                oMatrix.SelectRow(1, true, false);
                            }

                            // Auto Select
                            else if (pVal.ItemUID == "20")
                            {
                                string randomNo = oForm.DataSources.UserDataSources.Item(randomUDF).ValueEx;

                                oMatrix = oForm.Items.Item("14").Specific;
                                oMatrix.FlushToDataSource();
                                SAPbouiCOM.DataTable oDT1 = oForm.DataSources.DataTables.Item("oDT1");
                                int selectedrow = 0;
                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    try
                                    {
                                        if (oMatrix.IsRowSelected(i))
                                        {
                                            selectedrow = i - 1;
                                            break;
                                        }
                                    }
                                    catch { }
                                }
                                string itemcode = oDT1.GetValue("ItemCode", selectedrow);
                                string whscode = oDT1.GetValue("WhsCode", selectedrow);
                                string lineId = oDT1.GetValue("LineId", selectedrow);
                                string qty = oDT1.GetValue("Qty", selectedrow);
                                double dblRequiredQty = qty == string.Empty ? 0 : double.Parse(qty);

                                double dblSelectedQty = GetItemQuantity(randomNo, lineId);
                                if (dblSelectedQty == dblRequiredQty)
                                {
                                    return;
                                }
                                double dblPendingQty = dblRequiredQty - dblSelectedQty;
                                string todayDate = DateTime.Now.ToString("yyyyMMdd");
                                oRs = GetBatch(itemcode, whscode, randomNo);
                                while (!oRs.EoF)
                                {
                                    if (dblPendingQty == 0)
                                    {
                                        break;
                                    }
                                    string batch = oRs.Fields.Item("DistNumber").Value.ToString();
                                    string stock = oRs.Fields.Item("Stock").Value.ToString();
                                    double dblStock = double.Parse(stock);
                                    string selQty = "1";
                                    if (dblStock >= dblPendingQty)
                                    {
                                        selQty = dblPendingQty.ToString();
                                        dblPendingQty = 0;
                                    }
                                    else
                                    {
                                        dblPendingQty = dblPendingQty - dblStock;
                                        selQty = dblStock.ToString();
                                    }

                                    string code = objclsCommon.SelectRecord("SELECT MAX(Cast(\"Code\" AS NUMERIC(19,0))) FROM \"@RBATCH\" ");
                                    code = code == string.Empty ? "0" : code;
                                    Int32 iCode = Int32.Parse(code) + 1;
                                    sbQuery = new StringBuilder();
                                    sbQuery.Append("INSERT INTO \"@RBATCH\"(\"Code\",\"Name\",\"U_LineId\",\"U_ItemCode\",\"U_WhsCode\",\"U_BatchNo\",\"U_Qty\",\"U_BaseEn\",\"U_Date\") ");
                                    sbQuery.Append("VALUES('" + iCode.ToString() + "','" + iCode.ToString() + "','" + lineId + "','" + itemcode + "','" + whscode + "','" + batch + "','" + selQty + "','" + randomNo + "','" + todayDate + "' ) ");
                                    objclsCommon.SelectRecord(sbQuery.ToString());
                                    oRs.MoveNext();
                                }
                                FillAvailableMatrix(itemcode, whscode, randomNo);
                                FillSelectedMatrix(randomNo, lineId);
                                if (oForm.Mode == BoFormMode.fm_UPDATE_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_OK_MODE;
                                }
                                oMatrix = oForm.Items.Item("4").Specific;
                                oMatrix.SelectRow(1, true, false);

                                oMatrix = oForm.Items.Item("15").Specific;
                                oMatrix.SelectRow(1, true, false);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "14")
                            {
                                if (pVal.ColUID == "V_-1")
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    string randomNo = oForm.DataSources.UserDataSources.Item(randomUDF).ValueEx;
                                    oMatrix = oForm.Items.Item(pVal.ItemUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDataTable = oForm.DataSources.DataTables.Item("oDT1");
                                    int iDatatableRowCount = oDataTable.Rows.Count;
                                    if (pVal.Row > iDatatableRowCount)
                                    {
                                        return;
                                    }
                                    string itemcode = oDataTable.GetValue("ItemCode", pVal.Row - 1).ToString();
                                    string whscode = oDataTable.GetValue("WhsCode", pVal.Row - 1).ToString();
                                    string lineId = oDataTable.GetValue("LineId", pVal.Row - 1).ToString();
                                    FillAvailableMatrix(itemcode, whscode, randomNo);
                                    FillSelectedMatrix(randomNo, lineId);

                                    oMatrix = oForm.Items.Item("4").Specific;
                                    oMatrix.SelectRow(1, true, false);

                                    oMatrix = oForm.Items.Item("15").Specific;
                                    oMatrix.SelectRow(1, true, false);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    //if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    //{
                    //    LoadForm(pVal.MenuUID);
                    //}
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm(string menuID, string baseFormMenuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);

                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add(randomUDF, BoDataType.dt_LONG_TEXT, 100);
                    oForm.DataSources.UserDataSources.Add(baseFormMenuIDUDF, BoDataType.dt_LONG_TEXT, 100);
                    oForm.DataSources.UserDataSources.Item(baseFormMenuIDUDF).ValueEx = baseFormMenuID;

                    //FillGrid("N");
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void FillGrid(string selection)
        {
            oForm = oApplication.Forms.ActiveForm;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("call Proc_SalesAgr_CopyFromSalesAgr_Documents ( '" + selection + "')");
            }
            else
            {

                //sbQuery.Append("EXEC Proc_SalesAgr_CopyFromSalesAgr_Documents '" + selection + "','" + cardcode + "' ");
            }
            sbQuery.Length = 0;
            sbQuery.Append(" SELECT '" + selection + "' as \"Selection\" ,  T0.\"DocNum\", T1.\"LineId\", T1.\"U_ItemCode\" as \"ItemCode\" ");
            sbQuery.Append(" ,T1.\"U_ItemName\" as \"ItemName\", T1.\"U_OpenQty\" \"Quantity\",T0.\"DocEntry\"   ");
            sbQuery.Append(" FROM \"" + clsDepartmentalIssue.headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + clsDepartmentalIssue.rowTable + "\" T1 ON T0.\"DocEntry\"= T1.\"DocEntry\" ");
            sbQuery.Append(" WHERE T1.\"U_OpenQty\" > 0");
            objclsCommon.FillGrid(oForm.UniqueID, gridDocumentsUID, gridDocumentsUID, sbQuery.ToString());
            SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridDocumentsUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
            oGrid.Columns.Item(0).Type = BoGridColumnType.gct_CheckBox;
        }


        public void FillAvailableMatrix(string itemcode, string whscode, string randomNo)
        {
            oForm = oApplication.Forms.ActiveForm;
            #region Fill Available Matrix
            SAPbouiCOM.DataTable oDT2 = null;
            try
            {
                oDT2 = oForm.DataSources.DataTables.Add("oDT2");
            }
            catch
            {
                oDT2 = oForm.DataSources.DataTables.Item("oDT2");
            }


            //itemcode = oDT1.GetValue("ItemCode", 0).ToString();
            //whscode = oDT1.GetValue("WhsCode", 0).ToString();
            //lineId = oDT1.GetValue("LineId", 0).ToString();

            string isSerOrBatchManaged = objclsCommon.IsItemSeriesOrBatchManaged(itemcode);
            string baseFormMenuID = oForm.DataSources.UserDataSources.Item(baseFormMenuIDUDF).ValueEx;
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT A.\"DistNumber\",SUM(\"Stock\") \"Stock\", Cast(0 AS NUMERIC(19,2)) AS \"SelQty\" FROM (  ");
            sbQuery.Append(" SELECT T2.\"DistNumber\",SUM(T0.\"Quantity\") \"Stock\",Cast(0 AS NUMERIC(19,2)) AS \"SelQty\"   ");
            sbQuery.Append(" FROM \"ITL1\" T0 ");
            sbQuery.Append(" INNER JOIN	\"OITL\" T1 ON T0.\"LogEntry\" = T1.\"LogEntry\" ");
            if (isSerOrBatchManaged == "B")
            {
                sbQuery.Append(" INNER JOIN	\"OBTN\" T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" and T0.\"SysNumber\" = T2.\"SysNumber\" ");
            }
            else
            {
                sbQuery.Append(" INNER JOIN	\"OSRN\" T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" and T0.\"SysNumber\" = T2.\"SysNumber\" ");
            }
            sbQuery.Append(" WHERE T2.\"ItemCode\" = '" + itemcode + "' AND T1.\"LocCode\" = '" + whscode + "' ");
            sbQuery.Append(" GROUP BY T2.\"DistNumber\"");
            sbQuery.Append(" Having SUM(T0.\"Quantity\")>0");

            if (baseFormMenuID == clsRGatePassOut.formMenuUID || baseFormMenuID == clsNonRGatePass.formMenuUID)
            {
                sbQuery.Append(" UNION ALL  ");
                sbQuery.Append(" SELECT T0.\"U_BatchNo\" as \"DistNumber\",- SUM(T0.\"U_Qty\") \"Stock\",Cast(0 AS NUMERIC(19,2)) AS \"SelQty\"   ");
                sbQuery.Append(" FROM \"" + CommonTables.RBatchTable + "\" T0 ");
                sbQuery.Append(" WHERE T0.\"U_ItemCode\" = '" + itemcode + "' AND T0.\"U_WhsCode\" = '" + whscode + "' ");
                sbQuery.Append(" AND T0.\"U_BaseEn\" = '" + randomNo + "'   ");
                sbQuery.Append(" GROUP BY T0.\"U_BatchNo\"");
                sbQuery.Append(" Having SUM(T0.\"U_Qty\")>0");
            }
            sbQuery.Append(" ) AS A GROUP BY A.\"DistNumber\" ");
            sbQuery.Append(" HAVING SUM(\"Stock\") > 0 ");



            oDT2.ExecuteQuery(sbQuery.ToString());
            oMatrix = oForm.Items.Item("4").Specific;
            oMatrix.Columns.Item("V_3").DataBind.Bind(oDT2.UniqueID, "DistNumber");
            oMatrix.Columns.Item("V_2").DataBind.Bind(oDT2.UniqueID, "Stock");
            oMatrix.Columns.Item("V_0").DataBind.Bind(oDT2.UniqueID, "SelQty");
            oMatrix.LoadFromDataSource();
            #endregion

        }

        public void FillSelectedMatrix(string randomNo, string lineId)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"U_BatchNo\" as \"DistNumber\",T0.\"U_Qty\" as \"SelQty\"    ");
            sbQuery.Append(" FROM \"@RBATCH\" T0 ");
            sbQuery.Append(" WHERE T0.\"U_LineId\" = '" + lineId + "' AND T0.\"U_BaseEn\" = '" + randomNo + "' ");
            SAPbouiCOM.DataTable oDT3 = null;
            try
            {
                oDT3 = oForm.DataSources.DataTables.Add("oDT3");
            }
            catch
            {
                oDT3 = oForm.DataSources.DataTables.Item("oDT3");
            }
            oDT3.ExecuteQuery(sbQuery.ToString());
            oMatrix = oForm.Items.Item("15").Specific;
            oMatrix.Columns.Item("V_1").DataBind.Bind(oDT3.UniqueID, "DistNumber");
            oMatrix.Columns.Item("V_0").DataBind.Bind(oDT3.UniqueID, "SelQty");
            oMatrix.LoadFromDataSource();
        }

        public double GetItemQuantity(string randomNo, string lineId)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT Sum(T0.\"U_Qty\")    ");
            sbQuery.Append(" FROM \"@RBATCH\" T0 ");
            sbQuery.Append(" WHERE T0.\"U_LineId\" = '" + lineId + "' AND T0.\"U_BaseEn\" = '" + randomNo + "' ");
            string qty = objclsCommon.SelectRecord(sbQuery.ToString());
            double dblQty = qty == string.Empty ? 0 : double.Parse(qty);
            return dblQty;
        }

        public SAPbobsCOM.Recordset GetBatch(string itemcode, string whscode, string randomNo)
        {
            oForm = oApplication.Forms.ActiveForm;
            string baseFormMenuID = oForm.DataSources.UserDataSources.Item(baseFormMenuIDUDF).ValueEx;

            sbQuery = new StringBuilder();
            //sbQuery.Append(" SELECT T2.\"DistNumber\",SUM(T0.\"Quantity\") \"Quantity\"  ");
            //sbQuery.Append(" FROM \"ITL1\" T0 ");
            //sbQuery.Append(" INNER JOIN	\"OITL\" T1 ON T0.\"LogEntry\" = T1.\"LogEntry\" ");
            //sbQuery.Append(" INNER JOIN	\"OBTN\" T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" and T0.\"SysNumber\" = T2.\"SysNumber\" ");
            //sbQuery.Append(" WHERE T2.\"ItemCode\" = '" + itemcode + "' AND T1.\"LocCode\" = '" + whscode + "' ");
            //sbQuery.Append(" GROUP BY T2.\"DistNumber\"");
            //sbQuery.Append(" Having SUM(T0.\"Quantity\")>0");
            sbQuery.Append(" SELECT A.\"DistNumber\",SUM(\"Stock\") \"Stock\", Cast(0 AS NUMERIC(19,2)) AS \"SelQty\" FROM (  ");
            sbQuery.Append(" SELECT T2.\"DistNumber\",SUM(T0.\"Quantity\") \"Stock\",Cast(0 AS NUMERIC(19,2)) AS \"SelQty\"   ");
            sbQuery.Append(" FROM \"ITL1\" T0 ");
            sbQuery.Append(" INNER JOIN	\"OITL\" T1 ON T0.\"LogEntry\" = T1.\"LogEntry\" ");
            sbQuery.Append(" INNER JOIN	\"OBTN\" T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" and T0.\"SysNumber\" = T2.\"SysNumber\" ");
            sbQuery.Append(" WHERE T2.\"ItemCode\" = '" + itemcode + "' AND T1.\"LocCode\" = '" + whscode + "' ");
            sbQuery.Append(" GROUP BY T2.\"DistNumber\"");
            sbQuery.Append(" Having SUM(T0.\"Quantity\")>0");
            if (baseFormMenuID == clsRGatePassOut.formMenuUID || baseFormMenuID == clsNonRGatePass.formMenuUID)
            {
                sbQuery.Append(" UNION ALL  ");
                sbQuery.Append(" SELECT T0.\"U_BatchNo\" as \"DistNumber\",- SUM(T0.\"U_Qty\") \"Stock\",Cast(0 AS NUMERIC(19,2)) AS \"SelQty\"   ");
                sbQuery.Append(" FROM \"" + CommonTables.RBatchTable + "\" T0 ");
                sbQuery.Append(" WHERE T0.\"U_ItemCode\" = '" + itemcode + "' AND T0.\"U_WhsCode\" = '" + whscode + "' ");
                sbQuery.Append(" AND T0.\"U_BaseEn\" = '" + randomNo + "'   ");
                sbQuery.Append(" GROUP BY T0.\"U_BatchNo\"");
                sbQuery.Append(" Having SUM(T0.\"U_Qty\")>0");
            }
            sbQuery.Append(" ) AS A GROUP BY A.\"DistNumber\" ");
            sbQuery.Append(" HAVING SUM(\"Stock\")  > 0  ");

            return objclsCommon.returnRecord(sbQuery.ToString());
        }

    }
}
