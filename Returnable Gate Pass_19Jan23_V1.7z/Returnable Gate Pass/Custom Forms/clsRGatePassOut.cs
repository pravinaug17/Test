﻿using RGatePass.Classes;
using RGatePass.Extensions;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace RGatePass.Custom_Forms
{
    class clsRGatePassOut : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "@RGPO";
        public const string rowTable = "@RGPO1";
        public const string objType = "RGPO";
        public const string formTypeEx = "RGPO";
        public const string formMenuUID = "RGPO";
        const string formTitle = "Returnable Gate Pass out";
        public const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_ItemCode";
        const string randomUDF = "U_Random";
        bool multiItemSelected = false;
        string cflSelected = "";
        string isGatePassApp = "";

        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            #region Before_Action == true

            if (pVal.Before_Action == true)
            {
                try
                {
                    #region T_et_ITEM_PRESSED

                    if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.ActiveForm;
                            if (oForm.Mode == BoFormMode.fm_ADD_MODE || oForm.Mode == BoFormMode.fm_UPDATE_MODE)
                            {
                                string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
                                if (cardcode == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select Business partner", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                oMatrix = oForm.Items.Item(matrixUID).Specific;
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix.FlushToDataSource();

                                #region Item Validation
                                if (oMatrix.VisualRowCount == 0)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select itemcode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    string itemcode = oDbDataSource.GetValue("U_ItemCode", i);
                                    if (i == 0)
                                    {
                                        if (itemcode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please select itemcode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }

                                    // Quantity validation
                                    string baseQuantity = oDbDataSource.GetValue("U_BaseQty", i).ToString();
                                    double dblBaseQuantity = baseQuantity == string.Empty ? 0 : double.Parse(baseQuantity);
                                    string quantity = oDbDataSource.GetValue("U_Qty", i).ToString();
                                    double dblQuantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                                    if (dblBaseQuantity > 0 && dblQuantity > dblBaseQuantity)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Quantity should be less than or equal to base quantity for Row: " + (i + 1).ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                                #endregion

                                string itEn = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ITEn", 0).Trim();

                                string lineId = "";
                                clsBatchSelection _clsBatchSelection = new clsBatchSelection();

                                if (itEn == string.Empty)
                                {
                                    string randomNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(randomUDF, 0).ToString();
                                    if (randomNo == string.Empty)
                                    {
                                        randomNo = objclsCommon.GetRandomNo();
                                        oForm.DataSources.DBDataSources.Item(headerTable).SetValue(randomUDF, 0, randomNo);
                                    }

                                    double rowQty = 0;
                                    bool isBatchAllocationPending = false;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        lineId = oDbDataSource.GetValue("LineId", i).ToString();
                                        string itemCode = oDbDataSource.GetValue("U_ItemCode", i).ToString();
                                        string isWQtyPost = oDbDataSource.GetValue("U_WQtyPost", i).ToString();
                                        if (isWQtyPost == "Y")
                                        {
                                            continue;
                                        }
                                        string quantity = oDbDataSource.GetValue("U_Qty", i).ToString();
                                        string instock = oDbDataSource.GetValue("U_StkInWhs", i).ToString();
                                        double dblQuantiy = quantity == string.Empty ? 0 : double.Parse(quantity);
                                        double dblInStock = instock == string.Empty ? 0 : double.Parse(instock);
                                        if (dblQuantiy > dblInStock)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Quantity falls into negative inventory for Row: " + Convert.ToString(i + 1));
                                            return;
                                        }
                                        string isSerOrBatchManaged = objclsCommon.IsItemSeriesOrBatchManaged(itemCode);
                                        if (isSerOrBatchManaged != string.Empty)
                                        {
                                            rowQty = double.Parse(oDbDataSource.GetValue("U_Qty", i).ToString());
                                            double dblSelectedBatchQty = _clsBatchSelection.GetItemQuantity(randomNo, lineId);
                                            if (rowQty > dblSelectedBatchQty)
                                            {
                                                isBatchAllocationPending = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (isBatchAllocationPending == true)
                                    {
                                        BubbleEvent = false;
                                        _clsBatchSelection.LoadForm(clsBatchSelection.formMenuUID, formMenuUID);
                                        oForm = oApplication.Forms.ActiveForm;
                                        oForm.DataSources.UserDataSources.Item(randomUDF).ValueEx = randomNo;
                                        oMatrix = oForm.Items.Item("14").Specific;

                                        #region Fill Header Matrix
                                        SAPbouiCOM.DataTable oDT1 = null;
                                        try
                                        {
                                            oDT1 = oForm.DataSources.DataTables.Add("oDT1");
                                        }
                                        catch
                                        {
                                            oDT1 = oForm.DataSources.DataTables.Item("oDT1");
                                        }
                                        sbQuery = new StringBuilder();
                                        int row = 0;
                                        string itemcode = "";
                                        string whscode = "";
                                        lineId = "";
                                        for (int i = 0; i < oDbDataSource.Size; i++)
                                        {
                                            string isWQtyPost = oDbDataSource.GetValue("U_WQtyPost", i).ToString();
                                            if (isWQtyPost == "Y")
                                            {
                                                continue;
                                            }
                                            itemcode = oDbDataSource.GetValue("U_ItemCode", i);
                                            string isSerOrBatchManaged = objclsCommon.IsItemSeriesOrBatchManaged(itemcode);
                                            if (isSerOrBatchManaged == string.Empty)
                                            {
                                                continue;
                                            }
                                            whscode = oDbDataSource.GetValue("U_FrWhs", i);
                                            string quantity = oDbDataSource.GetValue("U_Qty", i).ToString();
                                            lineId = oDbDataSource.GetValue("LineId", i).ToString();
                                            if (itemcode != string.Empty)
                                            {
                                                if (row > 0)
                                                {
                                                    sbQuery.Append(" UNION ALL ");
                                                }
                                                double dblSelectedQty = _clsBatchSelection.GetItemQuantity(randomNo, lineId);
                                                double dblRequiredQty = double.Parse(quantity) - dblSelectedQty;
                                                sbQuery.Append(" SELECT " + (row + 1).ToString() + " \"RowNo\", \"ItemCode\",\"ItemName\",'" + whscode + "' \"WhsCode\" ");
                                                sbQuery.Append(" ,'" + quantity + "' \"Qty\"  ");
                                                sbQuery.Append(" ,'" + dblRequiredQty.ToString() + "' \"TotNeed\"  ");
                                                sbQuery.Append(" ,'" + lineId + "' \"LineId\"  ");
                                                sbQuery.Append(" FROM OITM T0  ");
                                                sbQuery.Append(" WHERE \"ItemCode\" = '" + itemcode + "' ");
                                                row++;
                                            }
                                        }
                                        oDT1.ExecuteQuery(sbQuery.ToString());
                                        oMatrix.Columns.Item("V_-1").DataBind.Bind(oDT1.UniqueID, "RowNo");
                                        oMatrix.Columns.Item("V_4").DataBind.Bind(oDT1.UniqueID, "ItemCode");
                                        oMatrix.Columns.Item("V_3").DataBind.Bind(oDT1.UniqueID, "ItemName");
                                        oMatrix.Columns.Item("V_2").DataBind.Bind(oDT1.UniqueID, "WhsCode");
                                        oMatrix.Columns.Item("V_1").DataBind.Bind(oDT1.UniqueID, "Qty");
                                        oMatrix.Columns.Item("V_0").DataBind.Bind(oDT1.UniqueID, "TotNeed");
                                        oMatrix.Columns.Item("LineId").DataBind.Bind(oDT1.UniqueID, "LineId");
                                        oMatrix.LoadFromDataSource();
                                        oMatrix.SelectRow(1, true, false);

                                        #endregion

                                        itemcode = oDT1.GetValue("ItemCode", 0).ToString();
                                        whscode = oDT1.GetValue("WhsCode", 0).ToString();
                                        lineId = oDT1.GetValue("LineId", 0).ToString();


                                        #region Fill Available Batch Matrix

                                        _clsBatchSelection.FillAvailableMatrix(itemcode, whscode, randomNo);

                                        #endregion

                                        #region Fill Selected Batch Matrix

                                        _clsBatchSelection.FillSelectedMatrix(randomNo, lineId);

                                        #endregion

                                    }
                                }

                                if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                                {
                                    isGatePassApp = objclsCommon.IsGatePassApplicable(objType);
                                    if (isGatePassApp != "Y")
                                    {
                                        bool isTestSuccess = CreateIT_InTransaction(true);
                                        if (isTestSuccess == false)
                                        {
                                            BubbleEvent = false;
                                        }
                                    }
                                }
                            }
                        }

                        else if (pVal.ItemUID == "btCopy")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (oForm.Mode != BoFormMode.fm_ADD_MODE)
                            {
                                oApplication.StatusBar.SetText("Form should be in Add Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            string cardCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
                            if (cardCode == string.Empty)
                            {
                                oApplication.StatusBar.SetText("Select Business partner", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            string frWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FrWhs", 0).Trim();
                            if (frWhs == string.Empty)
                            {
                                oApplication.StatusBar.SetText("Select from warehouse", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            string toWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ToWhs", 0).Trim();
                            if (toWhs == string.Empty)
                            {
                                oApplication.StatusBar.SetText("Select to warehouse", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            string randomNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(randomUDF, 0).ToString();
                            if (randomNo == string.Empty)
                            {
                                randomNo = objclsCommon.GetRandomNo();
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue(randomUDF, 0, randomNo);
                            }
                            clsVariables.BaseForm = oForm;
                            clsCopyITR doc = new clsCopyITR();
                            doc.LoadForm(clsCopyITR.formMenuUID, frWhs, toWhs);
                            oForm = oApplication.Forms.ActiveForm;
                        }


                        else if (pVal.ItemUID == "btIT")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (oForm.Mode != BoFormMode.fm_OK_MODE)
                            {
                                oApplication.StatusBar.SetText("Form should be in Ok Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }

                            CreateIT_InTransaction(false);
                        }
                    }

                    #endregion

                    #region T_et_CHOOSE_FROM_LIST
                    else if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);

                        if (pVal.ItemUID == "U_FrWhs" || pVal.ItemUID == "U_ToWhs")
                        {
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string branch = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BPLId", 0).Trim();
                            List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                            clsCFLEntityList.Add(new clsCFLEntity { Alias = "BPLid", CondVal = branch, Operation = BoConditionOperation.co_EQUAL });
                            objclsCommon.AddChooseFromList_WithList(oForm, sCFL_ID, clsCFLEntityList);
                        }
                        else if (pVal.ItemUID == "btGP")
                        {
                            if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                            {
                                oApplication.StatusBar.SetText("You can't select gate entry in add mode");
                                BubbleEvent = false;
                                return;
                            }
                            string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();

                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string query = " select  DocEntry from[@OGATE] where U_CardCode = '" + cardcode + "' and U_ObjCode = 'RGP Out' and U_GStatus = 'O' AND Status = 'C' ";
                            objclsCommon.AddChooseFromList_WithQuery(oForm, sCFL_ID, "OGATE", query, "DocEntry");
                        }
                        else if (pVal.ItemUID == matrixUID)
                        {
                            if (pVal.ColUID == "U_FrWhs" || pVal.ColUID == "U_ToWhs")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                                string sCFL_ID = oCFLEvento.ChooseFromListUID;
                                string branch = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BPLId", 0).Trim();
                                List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                                clsCFLEntityList.Add(new clsCFLEntity { Alias = "BPLid", CondVal = branch, Operation = BoConditionOperation.co_EQUAL });
                                objclsCommon.AddChooseFromList_WithList(oForm, sCFL_ID, clsCFLEntityList);
                            }
                        }
                    }
                    #endregion

                    #region T_et_GOT_FOCUS
                    else if (pVal.EventType == BoEventTypes.et_GOT_FOCUS)
                    {
                        if (pVal.ColUID == "U_Qty")
                        {
                            //oForm = oApplication.Forms.Item(pVal.FormUID);
                            //oMatrix = oForm.Items.Item(pVal.ItemUID).Specific;
                            //oMatrix.FlushToDataSource();
                            //oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            //string gpEn = oDbDataSource.GetValue("U_GateEn", pVal.Row - 1).ToString();
                            //if (gpEn != string.Empty)
                            //{
                            //    BubbleEvent = false;
                            //    oEdit = oForm.Items.Item("U_Remarks").Specific;
                            //    oEdit.Active = true;

                            //}
                        }
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                }
            }
            #endregion

            #region Before_Action == false

            else
            {
                try
                {
                    #region F_et_CHOOSE_FROM_LIST
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.DataTable oDataTable = null;
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                        oDataTable = oCFLEvento.SelectedObjects;
                        string sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string Value = string.Empty;
                        if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                        {
                            return;
                        }

                        if (oCFLEvento.ChooseFromListUID == "CFL_BP")
                        {
                            string cardcode = oDataTable.GetValue(CommonFields.CardCode, 0).ToString();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_CardCode", 0, cardcode);
                            oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                            oCombo = oForm.Items.Item("U_ShipTo").Specific;
                            objclsCommon.FillCombo(oCombo, objclsCommon.FillAddressQuery(cardcode, "S"));
                            string shipTo = oDataTable.GetValue("ShipToDef", 0).ToString();
                            oDbDataSource.SetValue("U_ShipTo", 0, shipTo);
                            string fulladdress = objclsCommon.GetFullBPAddress(cardcode, shipTo, "S");
                            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Addr", 0, fulladdress);
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_FWHS")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_FrWhs", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_TWHS")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_ToWhs", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_GP")
                        {
                            string docEntry = oDataTable.GetValue(CommonFields.DocEntry, 0).ToString();
                            string dlEntry = oDataTable.GetValue("U_DLEntry", 0).ToString();

                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            for (int i = 0; i < oDbDataSource.Size; i++)
                            {
                                string lineId = oDbDataSource.GetValue("LineId", i).ToString();
                                string query = "SELECT * FROM [@OITEML1] WHERE  U_DLEntry = " + dlEntry + " AND U_LineID = '" + lineId + "'";
                                oRs = objclsCommon.returnRecord(query);
                                if (!oRs.EoF)
                                {
                                    oDbDataSource.SetValue("U_Qty", i, oRs.Fields.Item("U_ChQty").Value.ToString());
                                    oDbDataSource.SetValue("U_BaseQty", i, oRs.Fields.Item("U_ChQty").Value.ToString());

                                    oDbDataSource.SetValue("U_OpenQty", i, oRs.Fields.Item("U_ChQty").Value.ToString());
                                    oDbDataSource.SetValue("U_GateEn", i, docEntry);
                                }
                            }
                            oMatrix.LoadFromDataSource();
                            if (oForm.Mode == BoFormMode.fm_OK_MODE)
                            {
                                oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                            }
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_ITEM" || oCFLEvento.ChooseFromListUID == "CFL_ITEMN")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_ItemCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            oDbDataSource.SetValue("U_ItemName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            oDbDataSource.SetValue("U_InvUOM", pVal.Row - 1, oDataTable.GetValue(CommonFields.InvntryUom, 0).ToString());
                            oDbDataSource.SetValue("U_Qty", pVal.Row - 1, "1");
                            string itemcode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                            string frWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FrWhs", 0);
                            string toWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ToWhs", 0);
                            string purpose = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Purpose", 0);
                            string project = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Project", 0);

                            oDbDataSource.SetValue("U_FrWhs", pVal.Row - 1, frWhs);
                            oDbDataSource.SetValue("U_ToWhs", pVal.Row - 1, toWhs);
                            oDbDataSource.SetValue("U_Purpose", pVal.Row - 1, purpose);
                            oDbDataSource.SetValue("U_Project", pVal.Row - 1, project);
                            string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, frWhs));
                            oDbDataSource.SetValue("U_StkInWhs", pVal.Row - 1, stock);
                            if (oDataTable.Rows.Count > 1)
                            {
                                multiItemSelected = true;
                                cflSelected = oCFLEvento.ChooseFromListUID;
                            }
                            if (pVal.Row == oMatrix.RowCount)
                            {
                                oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                int RowNo = 1;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                    RowNo = RowNo + 1;
                                }
                            }
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_RFWHS")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_FrWhs", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            string itemcode = oDbDataSource.GetValue("U_ItemCode", pVal.Row - 1);
                            string whs = oDataTable.GetValue(CommonFields.WhsCode, 0).ToString();
                            string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, whs));
                            oDbDataSource.SetValue("U_StkInWhs", pVal.Row - 1, stock);
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_RTWHS")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_ToWhs", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_PRJ")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_Project", pVal.Row - 1, oDataTable.GetValue(CommonFields.PrjCode, 0).ToString());
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID.Contains("CFL_OCR"))
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue(pVal.ColUID, pVal.Row - 1, oDataTable.GetValue(CommonFields.OcrCode, 0).ToString());
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_PRJ")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_Project", pVal.Row - 1, oDataTable.GetValue(CommonFields.PrjCode, 0).ToString());
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID.Contains("CFL_OCR"))
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue(pVal.ColUID, pVal.Row - 1, oDataTable.GetValue(CommonFields.OcrCode, 0).ToString());
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                    }
                    #endregion

                    #region F_et_FORM_ACTIVATE
                    else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                    {
                        if (clsVariables.boolCFLSelected)
                        {
                            clsVariables.boolCFLSelected = false;
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                            clsVariables.RowNo = 0;

                            #region Multiple Item Selecion
                            if (multiItemSelected == true)
                            {
                                multiItemSelected = false;
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                string itemcode = "";
                                string itemname = "";
                                bool fillItemDetails = false;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    itemcode = oDbDataSource.GetValue("U_ItemCode", i).ToString();
                                    itemname = oDbDataSource.GetValue("U_ItemName", i).ToString();

                                    if ((itemcode == string.Empty && itemname != string.Empty) || (itemcode != string.Empty && itemname == string.Empty))
                                    {
                                        fillItemDetails = true;
                                        if (itemcode == string.Empty)
                                        {
                                            itemcode = objclsCommon.SelectRecord("SELECT \"ItemCode\" FROM OITM WHERE \"ItemName\" = '" + itemname + "'");
                                        }
                                        if (itemname == string.Empty)
                                        {
                                            itemname = objclsCommon.SelectRecord("SELECT \"ItemName\" FROM OITM WHERE \"ItemCode\" = '" + itemcode + "'");
                                        }
                                    }
                                    if (fillItemDetails == true)
                                    {
                                        fillItemDetails = false;
                                        string frWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FrWhs", 0);
                                        string toWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ToWhs", 0);
                                        string purpose = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Purpose", 0);
                                        string project = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Project", 0);

                                        oDbDataSource.SetValue("U_ItemCode", i, itemcode);
                                        oDbDataSource.SetValue("U_ItemName", i, itemname);
                                        string invUOM = objclsCommon.SelectRecord("SELECT \"InvntryUom\" FROM OITM WHERE \"ItemCode\" = '" + itemcode + "'");
                                        oDbDataSource.SetValue("U_InvUOM", i, invUOM);
                                        oDbDataSource.SetValue("U_Qty", i, "1");
                                        oDbDataSource.SetValue("U_FrWhs", i, frWhs);
                                        oDbDataSource.SetValue("U_ToWhs", i, toWhs);
                                        oDbDataSource.SetValue("U_Purpose", i, purpose);
                                        oDbDataSource.SetValue("U_Project", i, project);
                                        string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, frWhs));
                                        oDbDataSource.SetValue("U_StkInWhs", i, stock);
                                    }
                                }
                                int RowNo = 1;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                    RowNo = RowNo + 1;
                                }
                                oMatrix.LoadFromDataSource();
                            }
                            #endregion
                        }
                    }
                    #endregion

                    #region F_et_ITEM_PRESSED
                    else if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "1")
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                            if (oForm.Mode == BoFormMode.fm_OK_MODE)
                            {
                                objclsCommon.RefreshRecord();
                            }
                            else if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                            {
                                string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocNum", 0).Trim();
                                if (docNum == string.Empty)
                                {
                                    LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                }
                            }
                        }

                        else if (pVal.ItemUID == "U_WQtyPost")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            string wQtyPost = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(pVal.ItemUID, 0).ToString();

                            oMatrix = oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            for (int i = 0; i < oDbDataSource.Size; i++)
                            {
                                oDbDataSource.SetValue("U_WQtyPost", i, wQtyPost);
                            }
                            oMatrix.LoadFromDataSource();
                        }
                    }
                    #endregion

                    #region F_et_COMBO_SELECT
                    else if (pVal.EventType == BoEventTypes.et_COMBO_SELECT)
                    {
                        if (pVal.ItemUID == "U_ShipTo")
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                            string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
                            string shipTo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(pVal.ItemUID, 0).Trim();
                            string fulladdress = objclsCommon.GetFullBPAddress(cardcode, shipTo, "S");
                            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Addr", 0, fulladdress);
                        }
                    }
                    #endregion


                }
                catch (Exception ex)
                {
                }
            }
            #endregion

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD
                        || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                        string canceled = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Canceled", 0).Trim();
                        sbQuery = new StringBuilder();
                        sbQuery.Append(" DELETE FROM \"" + rowTable + "\" ");
                        sbQuery.Append(" WHERE \"DocEntry\" = '" + docEntry + "' AND \"U_ItemCode\" IS NULL ");
                        objclsCommon.SelectRecord(sbQuery.ToString());

                        sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE \"" + rowTable + "\" ");
                        sbQuery.Append(" SET \"U_OpenQty\" = \"U_Qty\",\"U_LineStat\" = 'O' ");
                        sbQuery.Append(" WHERE \"DocEntry\" = '" + docEntry + "'   ");
                        objclsCommon.SelectRecord(sbQuery.ToString());

                        sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE T0 ");
                        sbQuery.Append(" SET  \"U_GStatus\" = 'C'  ");
                        sbQuery.Append(" FROM  \"" + CommonTables.GatePassTable + "\" T0 ");
                        sbQuery.Append(" INNER JOIN  \"" + rowTable + "\" T1 ON  T0.\"DocEntry\" = T1.\"U_GateEn\" ");
                        sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + docEntry + "'   ");
                        objclsCommon.SelectRecord(sbQuery.ToString());


                        //CreateIT_InTransaction(false, docEntry);
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                        string ITdocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ITEn", 0).Trim();
                        objclsCommon.FillCombo_Series_Custom(oForm, objType, "", "");
                        oForm.Items.Item("btGP").Disable();
                        if (ITdocEntry != string.Empty)
                        {
                            oForm.Mode = BoFormMode.fm_VIEW_MODE;
                            objclsCommon.EnableDisableMatrixMenus(oForm, false);
                        }
                        else
                        {
                            oForm.Mode = BoFormMode.fm_OK_MODE;
                            objclsCommon.EnableDisableMatrixMenus(oForm, true);
                            sbQuery = new StringBuilder();
                            sbQuery.Append(" SELECT * FROM \"" + rowTable + "\" ");
                            sbQuery.Append(" WHERE \"DocEntry\" = '" + docEntry + "' AND ISNULL(\"U_GateEn\",'')!='' ");
                            oRs = objclsCommon.returnRecord(sbQuery.ToString());
                            
                            if (oRs.RecordCount > 0)
                            {
                                oForm.Items.Item(matrixUID).Disable();                            
                            }
                            else
                            {
                                oForm.Items.Item(matrixUID).Enable();
                                oForm.Items.Item("btGP").Enable();
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }


                if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                {
                    LoadForm(pVal.MenuUID);
                }
                else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                {
                    oForm = oApplication.Forms.ActiveForm;
                    objclsCommon.AddRow(oForm, matrixUID, rowTable, matrixPrimaryUDF);
                }
                else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                {
                    oForm = oApplication.Forms.ActiveForm;
                    objclsCommon.DeleteRow(oForm, matrixUID, rowTable, matrixPrimaryUDF);
                }
                else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DuplicateRecord))
                {
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(randomUDF, 0, string.Empty);
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_ITEn", 0, string.Empty);
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_ITNo", 0, string.Empty);
                    oMatrix = oForm.Items.Item(matrixUID).Specific;
                    oMatrix.FlushToDataSource();
                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                    for (int i = 0; i < oDbDataSource.Size; i++)
                    {
                        oDbDataSource.SetValue("U_OpenQty",i,string.Empty);
                        oDbDataSource.SetValue("U_BaseEntry",i,string.Empty);
                        oDbDataSource.SetValue("U_BaseLine",i,string.Empty);
                        oDbDataSource.SetValue("U_BaseType",i,string.Empty);
                        oDbDataSource.SetValue("U_BaseQty",i,string.Empty);
                        oDbDataSource.SetValue("U_GateEn",i,string.Empty);
                    }
                    oMatrix.LoadFromDataSource();
                    objclsCommon.EnableDisableMatrixMenus(oForm, true);
                }
            }
        }

        public void LoadForm(string menuID)
        {
            if (menuID == formMenuUID)
            {
                oForm = objclsCommon.LoadXML(formMenuUID, "DocNum", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRecord), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRecord), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CancelRecord), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRecord), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.LayoutManager), true);
                string ReportType = objclsCommon.SelectRecord("SELECT \"CODE\" FROM \"RTYP\" WHERE \"MNU_ID\" ='" + menuID + "' AND \"ADD_NAME\" ='" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + "'");
                if (ReportType != string.Empty)
                {
                    oForm.ReportType = ReportType; //(Code of RTYP table)
                }

                isGatePassApp = objclsCommon.IsGatePassApplicable(objType);
                if (isGatePassApp != "Y")
                {
                    oForm.Items.Item("btCG").Visible = false;
                }
                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT T0.\"BPLId\", T0.\"BPLName\" FROM OBPL T0 WHERE \"Disabled\" = 'N'");
                oCombo = oForm.Items.Item("U_BPLId").Specific;
                objclsCommon.FillCombo(oCombo, sbQuery.ToString());


                #region Active BP
                List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "ValidFor", CondVal = "Y", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_BP", clsCFLEntityList);
                #endregion

                oMatrix = oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }

                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT T0.\"Code\", T0.\"Name\" FROM \"@PURFOR\" T0 ");
                oCombo = oMatrix.GetCellSpecific("U_IssueF", 1);
                objclsCommon.FillCombo(oCombo, sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT T0.\"Code\", T0.\"Name\" FROM \"@COSTCENT\" T0 ");
                oCombo = oMatrix.GetCellSpecific("U_CostCent", 1);
                objclsCommon.FillCombo(oCombo, sbQuery.ToString());


                #region Fill Dimension
                oColumn = oMatrix.Columns.Item("U_Dim1");

                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 1 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "1", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR1", clsCFLEntityList);

                //Dimension 2
                oColumn = oMatrix.Columns.Item("U_Dim2");

                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 2 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                
                clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "2", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR2", clsCFLEntityList);

                //Dimension 3
                oColumn = oMatrix.Columns.Item("U_Dim3");

                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 3 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "3", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR3", clsCFLEntityList);

                //Dimension 4
                oColumn = oMatrix.Columns.Item("U_Dim4");
                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 4 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "4", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR4", clsCFLEntityList);


                //Dimension 5
                oColumn = oMatrix.Columns.Item("U_Dim5");

                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 5 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "5", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR5", clsCFLEntityList);

                #endregion
            }
            else
            {
                oForm = oApplication.Forms.ActiveForm;
            }
            oForm.Items.Item("DocNum").EnableinFindMode();
            oForm.Items.Item("Series").EnableinAddMode();
            oForm.Items.Item("U_CardCode").EnableinAddMode();
            oForm.Items.Item("U_FrWhs").EnableinAddMode();
            oForm.Items.Item("U_ToWhs").EnableinAddMode();
            oForm.Items.Item("U_BPLId").EnableinAddMode();
            oForm.Items.Item("U_ShipTo").EnableinAddMode();
            oForm.Items.Item("U_Addr").EnableinAddMode();
            oForm.Items.Item("U_WQtyPost").EnableinAddMode();
            oForm.Items.Item("U_PostDate").EnableinAddMode();
            //oForm.Items.Item(matrixUID).EnableinAddMode();

            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"BPLId\" FROM USR6 T0 WHERE T0.\"UserCode\" = '" + oCompany.UserName + "'");
            string bplId = objclsCommon.SelectRecord(sbQuery.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_BPLId", 0, bplId);

            oMatrix = oForm.Items.Item(matrixUID).Specific;

            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }
            objclsCommon.EnableDisableMatrixMenus(oForm, true);
            #region Series And DocNum

            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_PostDate").Specific;
                oEdit.String = "t";

                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_DocDate").Specific;
                oEdit.String = "t";

                objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_PostDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string docnum = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, docnum);

                #endregion

            }
            catch { }
            #endregion

        }

        private void CreateIT(string docEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            string random = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(randomUDF, 0).Trim();

            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT * FROM \"" + headerTable + "\" ");
            sbQuery.Append("  WHERE \"DocEntry\" = '" + docEntry + "'  ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("  AND IFNULL(\"U_ITEn\",'') = '' ");
            }
            else
            {
                sbQuery.Append("   AND ISNULL(\"U_ITEn\",'') ='' ");
            }
            oRs = objclsCommon.returnRecord(sbQuery.ToString());
            if (oRs.RecordCount == 0)
            {
                return;
            }

            SAPbobsCOM.StockTransfer doc = (SAPbobsCOM.StockTransfer)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oStockTransfer);
            string docDate = oRs.Fields.Item("U_DocDate").Value.ToString();
            string postDate = oRs.Fields.Item("U_PostDate").Value.ToString();
            doc.DocDate = Convert.ToDateTime(postDate);
            doc.TaxDate = Convert.ToDateTime(docDate);
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT *  ");
            sbQuery.Append(" FROM \"" + rowTable + "\" ");
            sbQuery.Append("  WHERE \"DocEntry\" = '" + docEntry + "' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("  AND (IFNULL(\"U_WQtyPost\",'N') = 'N'  OR \"U_WQtyPost\"='' ) AND IFNULL(\"U_ItemCode\",'') != '' ");
            }
            else
            {
                sbQuery.Append("  AND (ISNULL(\"U_WQtyPost\",'N') = 'N' OR \"U_WQtyPost\"='') AND ISNULL(\"U_ItemCode\",'') !='' ");
            }
            SAPbobsCOM.Recordset oRsRows = objclsCommon.returnRecord(sbQuery.ToString());
            string seriesRemark = objclsCommon.SeriesRemark(objType);
            string series = objclsCommon.GetSeries("67", DateTime.Now.ToString("yyyyMMdd"), seriesRemark);
            if (series != string.Empty)
            {
                doc.Series = int.Parse(series);
            }
            doc.CardCode = oRs.Fields.Item("U_CardCode").Value;
            doc.Comments = oRs.Fields.Item("U_Remarks").Value;

            doc.FromWarehouse = oRsRows.Fields.Item("U_FrWhs").Value;
            doc.ToWarehouse = oRsRows.Fields.Item("U_ToWhs").Value;

            string bplId = oRs.Fields.Item("U_BPLId").Value.ToString();
            if (bplId != string.Empty)
            {
                //doc.BPLID = bplId;
            }
            int rowNo = 0;
            while (!oRsRows.EoF)
            {
                if (rowNo > 0)
                {
                }
                doc.Lines.SetCurrentLine(rowNo);

                string itemcode = oRsRows.Fields.Item("U_ItemCode").Value;
                string lineId = oRsRows.Fields.Item("LineId").Value.ToString();
                doc.Lines.ItemCode = itemcode;
                doc.Lines.WarehouseCode = oRsRows.Fields.Item("U_ToWhs").Value;
                doc.Lines.Quantity = oRsRows.Fields.Item("U_Qty").Value;
                doc.Lines.UnitPrice = double.Parse(oRsRows.Fields.Item("U_InfoPri").Value.ToString());
                try
                {
                    doc.Lines.UserFields.Fields.Item("U_FreeTxt").Value = oRsRows.Fields.Item("U_Purpose").Value.ToString();
                }
                catch { }
                if (oRsRows.Fields.Item("U_Project").Value.ToString() != string.Empty)
                {
                    doc.Lines.ProjectCode = oRsRows.Fields.Item("U_Project").Value.ToString();
                }
                if (oRsRows.Fields.Item("U_Dim1").Value.ToString() != string.Empty)
                {
                    doc.Lines.DistributionRule = oRsRows.Fields.Item("U_Dim1").Value.ToString();
                }
                if (oRsRows.Fields.Item("U_Dim2").Value.ToString() != string.Empty)
                {
                    doc.Lines.DistributionRule2 = oRsRows.Fields.Item("U_Dim2").Value.ToString();
                }
                if (oRsRows.Fields.Item("U_Dim3").Value.ToString() != string.Empty)
                {
                    doc.Lines.DistributionRule3 = oRsRows.Fields.Item("U_Dim3").Value.ToString();
                }
                if (oRsRows.Fields.Item("U_Dim4").Value.ToString() != string.Empty)
                {
                    doc.Lines.DistributionRule4 = oRsRows.Fields.Item("U_Dim4").Value.ToString();
                }
                if (oRsRows.Fields.Item("U_Dim5").Value.ToString() != string.Empty)
                {
                    doc.Lines.DistributionRule5 = oRsRows.Fields.Item("U_Dim5").Value.ToString();
                }

                string isItemSerorBatchManaged = objclsCommon.IsItemSeriesOrBatchManaged(itemcode);
                if (isItemSerorBatchManaged != string.Empty)
                {
                    sbQuery = new StringBuilder();
                    sbQuery.Append("SELECT * FROM \"" + CommonTables.RBatchTable + "\" WHERE \"U_BaseEn\" = '" + random + "' AND \"U_LineId\" = '" + lineId + "' ");
                    SAPbobsCOM.Recordset oRsSerBatch = objclsCommon.returnRecord(sbQuery.ToString());
                    int iSerBatch = 0;
                    if (isItemSerorBatchManaged == "B")
                    {
                        while (!oRsSerBatch.EoF)
                        {
                            if (iSerBatch > 0)
                            {
                                doc.Lines.BatchNumbers.SetCurrentLine(iSerBatch);
                            }
                            doc.Lines.BatchNumbers.BatchNumber = oRsSerBatch.Fields.Item("U_BatchNo").Value;
                            doc.Lines.BatchNumbers.Quantity = oRsSerBatch.Fields.Item("U_Qty").Value;
                            doc.Lines.BatchNumbers.Add();
                            iSerBatch++;
                            oRsSerBatch.MoveNext();
                        }
                    }
                    else if (isItemSerorBatchManaged == "S")
                    {
                        while (!oRsSerBatch.EoF)
                        {
                            if (iSerBatch > 0)
                            {
                                doc.Lines.SerialNumbers.SetCurrentLine(iSerBatch);
                            }
                            doc.Lines.SerialNumbers.InternalSerialNumber = oRsSerBatch.Fields.Item("U_BatchNo").Value;
                            doc.Lines.SerialNumbers.Quantity = oRsSerBatch.Fields.Item("U_Qty").Value;
                            doc.Lines.SerialNumbers.Add();
                            iSerBatch++;
                            oRsSerBatch.MoveNext();
                        }
                    }
                }
                doc.Lines.Add();
                rowNo = rowNo + 1;
                oRsRows.MoveNext();
            }

            int ii = doc.Add();
            if (ii != 0)
            {
                int err_code;
                string err_msg;
                oCompany.GetLastError(out err_code, out err_msg);
                oApplication.StatusBar.SetText("GenerateIT Exception: " + err_msg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                oApplication.MessageBox("GenerateIT Exception: " + err_msg);
            }
            else
            {
                string newDocEntry = oCompany.GetNewObjectKey();
                string newDocNum = objclsCommon.SelectRecord("SELECT \"DocNum\" FROM OWTR WHERE \"DocEntry\" = '" + newDocEntry + "'");
                sbQuery = new StringBuilder();
                sbQuery.Append(" UPDATE \"" + headerTable + "\" SET \"U_ITEn\"='" + newDocEntry + "',\"U_ITNo\"='" + newDocNum + "'  WHERE \"DocEntry\" = '" + docEntry + "'");
                objclsCommon.SelectRecord(sbQuery.ToString());

                objclsCommon.SelectRecord("DELETE FROM \"" + CommonTables.RBatchTable + "\" WHERE \"U_BaseEn\" = '" + random + "' ");
                oApplication.StatusBar.SetText("IT created successfully", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            }
        }

        private bool CreateIT_InTransaction(bool isTest)
        {
            oForm = oApplication.Forms.ActiveForm;
            string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
            string random = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(randomUDF, 0).Trim();

            #region Check Auto Entry To Create or not
            oMatrix = oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

            bool createNewDocument = false;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string itemcode = oDbDataSource.GetValue("U_ItemCode", i).ToString();
                if (itemcode == string.Empty)
                {
                    continue;
                }
                string lineId = oDbDataSource.GetValue("LineId", i).ToString();
                string wqtyPost = oDbDataSource.GetValue("U_WQtyPost", i).ToString();
                if (wqtyPost == "Y")
                {
                    continue;
                }
                createNewDocument = true;
                break;
            }
            if (createNewDocument == false)
            {
                return true;
            }
            #endregion

            if (isTest == false)
            {
                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT * FROM \"" + headerTable + "\" ");
                sbQuery.Append("  WHERE \"DocEntry\" = '" + docEntry + "'  ");
                if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                {
                    sbQuery.Append("  AND IFNULL(\"U_ITEn\",'') = '' ");
                }
                else
                {
                    sbQuery.Append("   AND ISNULL(\"U_ITEn\",'') ='' ");
                }
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    return true;
                }
            }

            try
            {
                if (isTest == true)
                {
                    oCompany.StartTransaction();
                    oApplication.StatusBar.SetText("Please wait...Validating entry", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                }
                else
                {
                    oApplication.StatusBar.SetText("Please wait...creating entry", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                }
                SAPbobsCOM.StockTransfer doc = (SAPbobsCOM.StockTransfer)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oStockTransfer);

                string seriesRemark = objclsCommon.SeriesRemark(objType);
                string series = objclsCommon.GetSeries("67", DateTime.Now.ToString("yyyyMMdd"), seriesRemark);
                if (series != string.Empty)
                {
                    doc.Series = int.Parse(series);
                }
                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                string docDate = oDbDataSource.GetValue("U_DocDate", 0).ToString();
                string postDate = oDbDataSource.GetValue("U_PostDate", 0).ToString(); // oRs.Fields.Item("U_PostDate").Value.ToString();
                doc.DocDate = DateTime.ParseExact(postDate, "yyyyMMdd", CultureInfo.InvariantCulture);
                doc.TaxDate = DateTime.ParseExact(docDate, "yyyyMMdd", CultureInfo.InvariantCulture);
                doc.CardCode = oDbDataSource.GetValue("U_CardCode", 0).ToString();
                doc.Comments = oDbDataSource.GetValue("U_Remarks", 0).ToString();

                string bplId = oDbDataSource.GetValue("U_BPLId", 0).ToString();
                if (bplId != string.Empty)
                {
                    //doc.BPLID = bplId;
                }
                int rowNo = 0;

                #region Rows
                oMatrix = oForm.Items.Item(matrixUID).Specific;
                oMatrix.FlushToDataSource();
                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

                for (int i = 0; i < oDbDataSource.Size; i++)
                {
                    if (rowNo > 0)
                    {
                        doc.Lines.SetCurrentLine(rowNo);
                    }
                    else
                    {
                        doc.FromWarehouse = oDbDataSource.GetValue("U_FrWhs", i).ToString();
                        doc.ToWarehouse = oDbDataSource.GetValue("U_ToWhs", i).ToString();
                    }
                    string itemcode = oDbDataSource.GetValue("U_ItemCode", i).ToString();
                    if (itemcode == string.Empty)
                    {
                        continue;
                    }
                    string wqtyPost = oDbDataSource.GetValue("U_WQtyPost", i).ToString();
                    if (wqtyPost == "Y")
                    {
                        continue;
                    }
                    string lineId = oDbDataSource.GetValue("LineId", i).ToString();
                    doc.Lines.ItemCode = itemcode;

                    doc.Lines.WarehouseCode = oDbDataSource.GetValue("U_ToWhs", i).ToString();
                    doc.Lines.Quantity = double.Parse(oDbDataSource.GetValue("U_Qty", i).ToString());
                    doc.Lines.UnitPrice = double.Parse(oDbDataSource.GetValue("U_InfoPri", i).ToString());
                    try
                    {
                        doc.Lines.UserFields.Fields.Item("U_FreeTxt").Value = oDbDataSource.GetValue("U_Purpose", i).ToString();
                    }
                    catch { }
                    if (oDbDataSource.GetValue("U_Project", i).ToString() != string.Empty)
                    {
                        doc.Lines.ProjectCode = oDbDataSource.GetValue("U_Project", i).ToString();
                    }
                    if (oDbDataSource.GetValue("U_Dim1", i).ToString() != string.Empty)
                    {
                        doc.Lines.DistributionRule = oDbDataSource.GetValue("U_Dim1", i).ToString();
                    }
                    if (oDbDataSource.GetValue("U_Dim2", i).ToString() != string.Empty)
                    {
                        doc.Lines.DistributionRule2 = oDbDataSource.GetValue("U_Dim2", i).ToString();
                    }
                    if (oDbDataSource.GetValue("U_Dim3", i).ToString() != string.Empty)
                    {
                        doc.Lines.DistributionRule3 = oDbDataSource.GetValue("U_Dim3", i).ToString();
                    }
                    if (oDbDataSource.GetValue("U_Dim4", i).ToString() != string.Empty)
                    {
                        doc.Lines.DistributionRule4 = oDbDataSource.GetValue("U_Dim4", i).ToString();
                    }
                    if (oDbDataSource.GetValue("U_Dim5", i).ToString() != string.Empty)
                    {
                        doc.Lines.DistributionRule5 = oDbDataSource.GetValue("U_Dim5", i).ToString();
                    }

                    try
                    {
                        doc.Lines.UserFields.Fields.Item("U_Remark").Value = oDbDataSource.GetValue("U_Remark", i).ToString();
                    }
                    catch { }

                    try
                    {
                        doc.Lines.UserFields.Fields.Item("U_IssueF").Value = oDbDataSource.GetValue("U_Purchasefor", i).ToString();
                    }
                    catch { }

                    try
                    {
                        doc.Lines.UserFields.Fields.Item("U_CostCent").Value = oDbDataSource.GetValue("U_cost_center", i).ToString();
                    }
                    catch { }

                    string isItemSerorBatchManaged = objclsCommon.IsItemSeriesOrBatchManaged(itemcode);
                    if (isItemSerorBatchManaged != string.Empty)
                    {
                        sbQuery = new StringBuilder();
                        sbQuery.Append("SELECT * FROM \"" + CommonTables.RBatchTable + "\" WHERE \"U_BaseEn\" = '" + random + "' AND \"U_LineId\" = '" + lineId + "' ");
                        SAPbobsCOM.Recordset oRsSerBatch = objclsCommon.returnRecord(sbQuery.ToString());
                        int iSerBatch = 0;
                        if (isItemSerorBatchManaged == "B")
                        {
                            while (!oRsSerBatch.EoF)
                            {
                                if (iSerBatch > 0)
                                {
                                    doc.Lines.BatchNumbers.SetCurrentLine(iSerBatch);
                                }
                                doc.Lines.BatchNumbers.BatchNumber = oRsSerBatch.Fields.Item("U_BatchNo").Value;
                                doc.Lines.BatchNumbers.Quantity = oRsSerBatch.Fields.Item("U_Qty").Value;
                                doc.Lines.BatchNumbers.Add();
                                iSerBatch++;
                                oRsSerBatch.MoveNext();
                            }
                        }
                        else if (isItemSerorBatchManaged == "S")
                        {
                            while (!oRsSerBatch.EoF)
                            {
                                if (iSerBatch > 0)
                                {
                                    doc.Lines.SerialNumbers.SetCurrentLine(iSerBatch);
                                }
                                doc.Lines.SerialNumbers.InternalSerialNumber = oRsSerBatch.Fields.Item("U_BatchNo").Value;
                                doc.Lines.SerialNumbers.Quantity = oRsSerBatch.Fields.Item("U_Qty").Value;
                                doc.Lines.SerialNumbers.Add();
                                iSerBatch++;
                                oRsSerBatch.MoveNext();
                            }
                        }
                    }
                    doc.Lines.Add();
                    rowNo = rowNo + 1;
                }
                #endregion

                int ii = doc.Add();
                if (ii != 0)
                {
                    int err_code;
                    string err_msg;
                    oCompany.GetLastError(out err_code, out err_msg);
                    oApplication.StatusBar.SetText("Generate IT Exception: " + err_msg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    oApplication.MessageBox("Generate IT Exception: " + err_msg);
                }
                else
                {
                    if (isTest == true)
                    {
                        if (oCompany.InTransaction)
                        {
                            oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack);
                            return true;
                        }
                    }
                    else
                    {
                        string newDocEntry = oCompany.GetNewObjectKey();
                        string newDocNum = objclsCommon.SelectRecord("SELECT \"DocNum\" FROM OWTR WHERE \"DocEntry\" = '" + newDocEntry + "'");
                        sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE \"" + headerTable + "\" SET \"U_ITEn\"='" + newDocEntry + "',\"U_ITNo\"='" + newDocNum + "'  WHERE \"DocEntry\" = '" + docEntry + "'");
                        objclsCommon.SelectRecord(sbQuery.ToString());
                        objclsCommon.SelectRecord("DELETE FROM \"" + CommonTables.RBatchTable + "\" WHERE \"U_BaseEn\" = '" + random + "' ");
                        oApplication.StatusBar.SetText("IT created successfully", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Generate IT Exception: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            if (isTest == true)
            {
                if (oCompany.InTransaction)
                {
                    oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack);
                }
            }
            return false;
        }
    }
}
