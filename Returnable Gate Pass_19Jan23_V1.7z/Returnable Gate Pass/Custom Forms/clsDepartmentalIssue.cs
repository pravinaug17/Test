﻿using RGatePass.Classes;
using RGatePass.Extensions;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGatePass.Custom_Forms
{
    class clsDepartmentalIssue : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "@DMIR";
        public const string rowTable = "@DMIR1";
        public const string objType = "DMIR";
        public const string formTypeEx = "DMIR";
        public const string formMenuUID = "DMIR";
        const string formTitle = "Departmental Material Request Issue";
        public const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_ItemCode";
        bool multiItemSelected = false;
        string cflSelected = "";

        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            #region Before_Action == true

            if (pVal.Before_Action == true)
            {
                try
                {
                    if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.ActiveForm;
                            if (oForm.Mode == BoFormMode.fm_ADD_MODE || oForm.Mode == BoFormMode.fm_UPDATE_MODE)
                            {
                                string dept = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Dept", 0).Trim();
                                if (dept == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select Department", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                oMatrix = oForm.Items.Item(matrixUID).Specific;
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix.FlushToDataSource();

                                #region Item Validation
                                if (oMatrix.VisualRowCount == 0)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select itemcode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    string itemcode = oDbDataSource.GetValue("U_ItemCode", i);
                                    if (i == 0)
                                    {
                                        if (itemcode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please select itemcode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                    if (itemcode != string.Empty)
                                    {
                                        string whsCode = oDbDataSource.GetValue("U_FrWhs", i);
                                        string inStock = string.Empty;

                                        if (whsCode.ToLower() == "project")
                                        {
                                            inStock = oDbDataSource.GetValue("U_PrjStk", i);
                                        }
                                        else if (whsCode.ToLower() == "store")
                                        {
                                            inStock = oDbDataSource.GetValue("U_StoStk", i);
                                        }
                                        else if (whsCode.ToLower() == "c.store")
                                        {
                                            inStock = oDbDataSource.GetValue("U_CentStk", i);
                                        }
                                        else if (whsCode.ToLower() == "p_return")
                                        {
                                            inStock = oDbDataSource.GetValue("U_PRetStk", i);
                                        }
                                        else
                                        { 
                                        
                                        }
                                        double dblInStock = inStock == string.Empty ? 0 : double.Parse(inStock);
                                        string qty = oDbDataSource.GetValue("U_Qty", i);
                                        double dblQty = qty == string.Empty ? 0 : double.Parse(qty);
                                        if (dblQty > dblInStock)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Stock should be greater than quantity for Row:" + Convert.ToString(i + 1), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }

                                        string fromWarehouse = oDbDataSource.GetValue("U_FrWhs", i);
                                        if (fromWarehouse == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("From warehouse is mandatory for Row:" + Convert.ToString(i + 1), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        string toWarehouse = oDbDataSource.GetValue("U_ToWhs", i);
                                        if (toWarehouse == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("To warehouse is mandatory for Row:" + Convert.ToString(i + 1), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        string issueFor = oDbDataSource.GetValue("U_IssueF", i);
                                        if (issueFor == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Issue for is mandatory for Row:" + Convert.ToString(i + 1), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        string purpose = oDbDataSource.GetValue("U_Purpose", i);
                                        if (purpose == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Purpose is mandatory for Row:" + Convert.ToString(i + 1), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        string remark = oDbDataSource.GetValue("U_Remark", i);
                                        if (remark == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Remark is mandatory for Row:" + Convert.ToString(i + 1), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        string costcenter = oDbDataSource.GetValue("U_CostCent", i);
                                        if (costcenter == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Cos center is mandatory for Row:" + Convert.ToString(i + 1), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        string particular = oDbDataSource.GetValue("U_Pertic", i);
                                        if (particular == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Perticular is mandatory for Row:" + Convert.ToString(i + 1), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                    }
                    #region T_et_CHOOSE_FROM_LIST
                    else if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        if (pVal.ItemUID == "U_FrWhs" || pVal.ItemUID == "U_ToWhs")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string branch = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BPLId", 0).Trim();
                            List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                            clsCFLEntityList.Add(new clsCFLEntity { Alias = "BPLid", CondVal = branch, Operation = BoConditionOperation.co_EQUAL });
                            objclsCommon.AddChooseFromList_WithList(oForm, sCFL_ID, clsCFLEntityList);
                        }
                        else if (pVal.ItemUID == matrixUID)
                        {
                            if (pVal.ColUID == "U_FrWhs" || pVal.ColUID == "U_ToWhs")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                                string sCFL_ID = oCFLEvento.ChooseFromListUID;
                                string branch = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BPLId", 0).Trim();
                                List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                                clsCFLEntityList.Add(new clsCFLEntity { Alias = "BPLid", CondVal = branch, Operation = BoConditionOperation.co_EQUAL });
                                objclsCommon.AddChooseFromList_WithList(oForm, sCFL_ID, clsCFLEntityList);
                            }
                        }
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                }
            }
            #endregion

            #region Before_Action == false

            else
            {
                try
                {
                    #region F_et_ITEM_PRESSED
                    if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        if (pVal.ItemUID == "1")
                        {
                            if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                            {
                                string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocNum", 0).Trim();
                                if (docNum == string.Empty)
                                {
                                    LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                }
                            }
                        }

                        else if (pVal.ItemUID == "U_WQtyPost")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            string wQtyPost = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(pVal.ItemUID, 0).ToString();

                            oMatrix = oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            for (int i = 0; i < oDbDataSource.Size; i++)
                            {
                                oDbDataSource.SetValue("U_WQtyPost", i, wQtyPost);
                            }
                            oMatrix.LoadFromDataSource();
                        }

                    }
                    #endregion

                    #region F_et_CHOOSE_FROM_LIST
                    else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.DataTable oDataTable = null;
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                        oDataTable = oCFLEvento.SelectedObjects;
                        string sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string Value = string.Empty;
                        if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                        {
                            return;
                        }

                        if (oCFLEvento.ChooseFromListUID == "CFL_BP")
                        {
                            string cardcode = oDataTable.GetValue(CommonFields.CardCode, 0).ToString();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_CardCode", 0, cardcode);
                            oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_FWHS")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_FrWhs", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_TWHS")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_ToWhs", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_ITEM" || oCFLEvento.ChooseFromListUID == "CFL_ITEMN")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_ItemCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            oDbDataSource.SetValue("U_ItemName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            oDbDataSource.SetValue("U_InvUOM", pVal.Row - 1, oDataTable.GetValue(CommonFields.InvntryUom, 0).ToString());
                            oDbDataSource.SetValue("U_Qty", pVal.Row - 1, "1");
                            string frWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FrWhs", 0);
                            string toWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ToWhs", 0);
                            string purpose = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Purpose", 0);
                            string project = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Project", 0);

                            oDbDataSource.SetValue("U_FrWhs", pVal.Row - 1, frWhs);
                            oDbDataSource.SetValue("U_ToWhs", pVal.Row - 1, toWhs);
                            oDbDataSource.SetValue("U_Purpose", pVal.Row - 1, purpose);
                            oDbDataSource.SetValue("U_Project", pVal.Row - 1, project);
                            string itemcode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                            string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode));
                            oDbDataSource.SetValue("U_StkInWhs", pVal.Row - 1, stock);

                            stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, "Project"));
                            oDbDataSource.SetValue("U_PrjStk", pVal.Row - 1, stock);
                            stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, "Store"));
                            oDbDataSource.SetValue("U_StoStk", pVal.Row - 1, stock);
                            stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, "C.Store"));
                            oDbDataSource.SetValue("U_CentStk", pVal.Row - 1, stock);
                            stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, "P_Return"));
                            oDbDataSource.SetValue("U_PRetStk", pVal.Row - 1, stock);

                            if (oDataTable.Rows.Count > 1)
                            {
                                multiItemSelected = true;
                                cflSelected = oCFLEvento.ChooseFromListUID;
                            }
                            if (pVal.Row == oMatrix.RowCount)
                            {
                                oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                int RowNo = 1;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                    RowNo = RowNo + 1;
                                }
                            }
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_RFWHS")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_FrWhs", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            string itemcode = oDbDataSource.GetValue("U_ItemCode", pVal.Row - 1);
                            string whs = oDataTable.GetValue(CommonFields.WhsCode, 0).ToString();
                            string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode));
                            oDbDataSource.SetValue("U_StkInWhs", pVal.Row - 1, stock);
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = false;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_RTWHS")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_ToWhs", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_PRJ")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_Project", pVal.Row - 1, oDataTable.GetValue(CommonFields.PrjCode, 0).ToString());
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID.Contains("CFL_OCR"))
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue(pVal.ColUID, pVal.Row - 1, oDataTable.GetValue(CommonFields.OcrCode, 0).ToString());
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                    }
                    #endregion

                    #region F_et_FORM_ACTIVATE
                    else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                    {
                        if (clsVariables.boolCFLSelected)
                        {
                            clsVariables.boolCFLSelected = false;
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                            clsVariables.RowNo = 0;


                            #region Multiple Item Selecion
                            if (multiItemSelected == true)
                            {
                                multiItemSelected = false;
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                string itemcode = "";
                                string itemname = "";
                                bool fillItemDetails = false;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    itemcode = oDbDataSource.GetValue("U_ItemCode", i).ToString();
                                    itemname = oDbDataSource.GetValue("U_ItemName", i).ToString();

                                    if ((itemcode == string.Empty && itemname != string.Empty) || (itemcode != string.Empty && itemname == string.Empty))
                                    {
                                        fillItemDetails = true;
                                        if (itemcode == string.Empty)
                                        {
                                            itemcode = objclsCommon.SelectRecord("SELECT \"ItemCode\" FROM OITM WHERE \"ItemName\" = '" + itemname + "'");
                                        }
                                        if (itemname == string.Empty)
                                        {
                                            itemname = objclsCommon.SelectRecord("SELECT \"ItemName\" FROM OITM WHERE \"ItemCode\" = '" + itemcode + "'");
                                        }
                                    }
                                    if (fillItemDetails == true)
                                    {
                                        fillItemDetails = false;
                                        string frWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FrWhs", 0);
                                        string toWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ToWhs", 0);
                                        string purpose = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Purpose", 0);
                                        string project = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Project", 0);

                                        oDbDataSource.SetValue("U_ItemCode", i, itemcode);
                                        oDbDataSource.SetValue("U_ItemName", i, itemname);
                                        string invUOM = objclsCommon.SelectRecord("SELECT \"InvntryUom\" FROM OITM WHERE \"ItemCode\" = '" + itemcode + "'");
                                        oDbDataSource.SetValue("U_InvUOM", i, invUOM);
                                        oDbDataSource.SetValue("U_Qty", i, "1");
                                        oDbDataSource.SetValue("U_FrWhs", i, frWhs);
                                        oDbDataSource.SetValue("U_ToWhs", i, toWhs);
                                        oDbDataSource.SetValue("U_Purpose", i, purpose);
                                        oDbDataSource.SetValue("U_Project", i, project);
                                        string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode));
                                        oDbDataSource.SetValue("U_StkInWhs", i, stock);
                                        stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, "Project"));
                                        oDbDataSource.SetValue("U_PrjStk", i, stock);
                                        stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, "Store"));
                                        oDbDataSource.SetValue("U_StoStk", i, stock);
                                        stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, "C.Store"));
                                        oDbDataSource.SetValue("U_CentStk", i, stock);
                                        stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, "P_Return"));
                                        oDbDataSource.SetValue("U_PRetStk", i, stock);
                                    }
                                }
                                int RowNo = 1;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                    RowNo = RowNo + 1;
                                }
                                oMatrix.LoadFromDataSource();
                            }
                            #endregion

                        }
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                }
            }
            #endregion

        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DuplicateRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        objclsCommon.EnableDisableMatrixMenus(oForm, true);
                        oForm.DataSources.DBDataSources.Item(headerTable).SetValue("Canceled", 0, "N");
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }


                if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                {
                    LoadForm(pVal.MenuUID);
                }
                else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                {
                    oForm = oApplication.Forms.ActiveForm;
                    objclsCommon.AddRow(oForm, matrixUID, rowTable, matrixPrimaryUDF);
                }
                else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                {
                    oForm = oApplication.Forms.ActiveForm;
                    objclsCommon.DeleteRow(oForm, matrixUID, rowTable, matrixPrimaryUDF);
                }
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                        string canceled = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Canceled", 0).Trim();
                        sbQuery = new StringBuilder();
                        sbQuery.Append(" DELETE FROM \"" + rowTable + "\" ");
                        sbQuery.Append(" WHERE \"DocEntry\" = '" + docEntry + "' AND \"U_ItemCode\" IS NULL ");
                        objclsCommon.SelectRecord(sbQuery.ToString());

                        sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE \"" + rowTable + "\" ");
                        sbQuery.Append(" SET \"U_OpenQty\" = \"U_Qty\" ,\"U_LineStat\" = 'O' ");
                        sbQuery.Append(" WHERE \"DocEntry\" = '" + docEntry + "'   ");
                        objclsCommon.SelectRecord(sbQuery.ToString());

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        objclsCommon.FillCombo_Series_Custom(oForm, objType, "", "");
                        oForm.Mode = BoFormMode.fm_VIEW_MODE;
                        objclsCommon.EnableDisableMatrixMenus(oForm, false);
                        string canceled = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Canceled", 0).Trim();
                        if (canceled == "Y")
                        {
                            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CancelRecord), false);
                        }
                        else
                        {
                            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CancelRecord), true);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void LoadForm(string menuID)
        {
            if (menuID == formMenuUID)
            {
                oForm = objclsCommon.LoadXML(formMenuUID, "DocNum", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRecord), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRecord), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CancelRecord), true);
                //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRecord), true);
                //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.LayoutManager), true);
                string ReportType = objclsCommon.SelectRecord("SELECT CODE FROM RTYP WHERE MNU_ID='" + menuID + "' AND ADD_NAME='" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + "'");
                if (ReportType != string.Empty)
                {
                    oForm.ReportType = ReportType; //(Code of RTYP table)
                }

                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT T0.\"BPLId\", T0.\"BPLName\" FROM OBPL T0 WHERE \"Disabled\" = 'N'");
                oCombo = oForm.Items.Item("U_BPLId").Specific;
                objclsCommon.FillCombo(oCombo, sbQuery.ToString());


                oMatrix = oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }

                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT T0.\"Code\", T0.\"Name\" FROM \"@PURFOR\" T0 ");
                oCombo = oMatrix.GetCellSpecific("U_IssueF", 1);
                objclsCommon.FillCombo(oCombo, sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT T0.\"Code\", T0.\"Name\" FROM \"@COSTCENT\" T0 ");
                oCombo = oMatrix.GetCellSpecific("U_CostCent", 1);
                objclsCommon.FillCombo(oCombo, sbQuery.ToString());

                #region Fill Dimension
                oColumn = oMatrix.Columns.Item("U_Dim1");

                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 1 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "1", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR1", clsCFLEntityList);

                //Dimension 2
                oColumn = oMatrix.Columns.Item("U_Dim2");

                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 2 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "2", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR2", clsCFLEntityList);

                //Dimension 3
                oColumn = oMatrix.Columns.Item("U_Dim3");

                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 3 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "3", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR3", clsCFLEntityList);

                //Dimension 4
                oColumn = oMatrix.Columns.Item("U_Dim4");

                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 4 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "4", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR4", clsCFLEntityList);


                //Dimension 5
                oColumn = oMatrix.Columns.Item("U_Dim5");

                sbQuery.Length = 0;
                sbQuery.Append("SELECT T0.\"OcrCode\", T0.\"OcrName\" FROM OOCR T0 WHERE T0.\"DimCode\" = 5 ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oColumn.Editable = false;
                }
                else
                {
                    oColumn.Editable = true;
                }
                clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "DimCode", CondVal = "5", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_OCR5", clsCFLEntityList);

                #endregion
            }
            else
            {
                oForm = oApplication.Forms.ActiveForm;
            }

            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT T0.\"Code\", T0.\"Name\" FROM OUDP T0 ORDER BY T0.\"Code\" ");
            oCombo = oForm.Items.Item("U_Dept").Specific;
            objclsCommon.FillCombo(oCombo, sbQuery.ToString());
            string userDeptId = objclsCommon.SelectRecord("SELECT T0.\"Department\" FROM OUSR T0 WHERE T0.\"USER_CODE\" = '" + oCompany.UserName + "' ");
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Dept", 0, userDeptId);

            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"BPLId\" FROM USR6 T0 WHERE T0.\"UserCode\" = '" + oCompany.UserName + "'");
            string bplId = objclsCommon.SelectRecord(sbQuery.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_BPLId", 0, bplId);

            oForm.Items.Item("DocNum").EnableinFindMode();
            oForm.Items.Item("Series").EnableinAddMode();
            oForm.Items.Item("Canceled").EnableinFindMode();
            oMatrix = oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }
            objclsCommon.EnableDisableMatrixMenus(oForm, true);
             
            #region Series And DocNum

            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_PostDate").Specific;
                oEdit.String = "t";

                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_DocDate").Specific;
                oEdit.String = "t";

                objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_PostDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string docnum = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, docnum);

                #endregion

            }
            catch { }
            #endregion
        }
    }
}