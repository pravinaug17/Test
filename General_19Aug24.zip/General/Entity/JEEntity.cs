﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace General.Classes
{
    public class JEEntity
    {
        public string Series { get; set; }
        public string DocNo { get; set; }
        public string DocDate { get; set; }
        public string DueDate { get; set; }
        public string Location { get; set; }
        public string Branch { get; set; }
        public string Remarks { get; set; }
        public string JVNarration { get; set; }
        public string LineNo { get; set; }
        public string GLAcctBPCode { get; set; }
        public string GLAcctBPName { get; set; }
        public string Debit { get; set; }
        public string Credit { get; set; }
        public string EmployeeName { get; set; }
    }
}
