﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Header;

namespace General.Classes
{
    public class clsSaveStockItemsEntity
    {
        public string DocEntry { get; set; }
        public string tpin { get; set; }
        public string bhfId { get; set; }
        public int sarNo { get; set; }
        public int orgSarNo { get; set; }
        public string regTyCd { get; set; }
        public object custTpin { get; set; }
        public object custNm { get; set; }
        public object custBhfId { get; set; }
        public string sarTyCd { get; set; }
        public string ocrnDt { get; set; }
        public int totItemCnt { get; set; }
        public int totTaxblAmt { get; set; }
        public int totTaxAmt { get; set; }
        public int totAmt { get; set; }
        public object remark { get; set; }
        public string regrId { get; set; }
        public string regrNm { get; set; }
        public string modrNm { get; set; }
        public string modrId { get; set; }
        public List<clsSaveStockItemsListEntity> itemList { get; set; }
    }

    public class clsSaveStockItemsListEntity
    {
        public int itemSeq { get; set; }
        public string itemCd { get; set; }
        public string itemClsCd { get; set; }
        public string itemNm { get; set; }
        public object bcd { get; set; }
        public int totDcAmt { get; set; }
        public string pkgUnitCd { get; set; }
        public int pkg { get; set; }
        public string qtyUnitCd { get; set; }
        public int qty { get; set; }
        public double prc { get; set; }
        public int splyAmt { get; set; }
        public int dcRt { get; set; }
        public int dcAmt { get; set; }
        public string taxTyCd { get; set; }
        public object iplCatCd { get; set; }
        public object tlCatCd { get; set; }
        public object exciseCatCd { get; set; }
        public int taxblAmt { get; set; }
        public string vatCatCd { get; set; }
        public object iplTaxblAmt { get; set; }
        public object tlTaxblAmt { get; set; }
        public object exciseTaxblAmt { get; set; }
        public int taxAmt { get; set; }
        public object iplAmt { get; set; }
        public object tlAmt { get; set; }
        public object exciseTxAmt { get; set; }
        public int totAmt { get; set; }
    }

    

}
