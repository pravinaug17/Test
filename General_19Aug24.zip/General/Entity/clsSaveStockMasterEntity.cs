﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace General.Classes
{
    public class clsSaveStockMasterEntity
    {
        public string DocEntry { get; set; }
        public string tpin { get; set; }
        public string bhfId { get; set; }
        public string regrNm { get; set; }
        public string regrId { get; set; }
        public string modrNm { get; set; }
        public string modrId { get; set; }
        public List<clsSaveStockMasterItemEntity> stockItemList { get; set; }
    }

    public class clsSaveStockMasterItemEntity
    {
        public string itemCd { get; set; }

        public double rsdQty { get; set; }
    }

    

}
