﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace General.Classes
{
    public class clsBOMEntity
    {
        public string Id { get; set; }
        public string RecordType { get; set; }
        public string ParentSFId { get; set; }
        public string ItemCode { get; set; }
        public string BOMQty { get; set; }
        public string Qty { get; set; }
        public string WhsCode { get; set; }
        public string ProjCode { get; set; }
        public string ProjName { get; set; }
        public string Remarks { get; set; }
        public string BOQSr { get; set; }
        public string BOQUPr { get; set; }
        public string BOQPrice { get; set; }
        public string BOQQty { get; set; }
        public string BasePri { get; set; }
        public string BaseTot { get; set; }
        public string TotAmt { get; set; }
        public string BasicTot { get; set; }
        public string BOQTot { get; set; }
        public List<clsBOMRowsEntity> BOMLines { get; set; }
    }

    public class clsBOMRowsEntity
    {
        public string Id { get; set; }
        public string ItemCode { get; set; }
        public string BOMQty { get; set; }
        public string Qty { get; set; }
        public string UOM { get; set; }
        public string WhsCode { get; set; }
        public string Price { get; set; }
        public string LineTot { get; set; }
    }

    public class clsBOMResponse
    {
        public string SFID { get; set; }
        public string ItemCode { get; set; }
        public string ErrorMessage { get; set; }
        public List<clsBOMLinesResponse> BOMLines { get; set; }
    }
    public class clsBOMLinesResponse
    {
        public string SFID { get; set; }
        public string ItemCode { get; set; }
    }
    
}
