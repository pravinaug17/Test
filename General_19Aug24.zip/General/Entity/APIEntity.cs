﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace General.Classes
{
    public static class APIEntity
    {
        public static string Host { get; set; }
        public static string TPin { get; set; }
        public static string BhfId { get; set; }
        public static string SaveItem { get; set; }
        public static string UpdateItem { get; set; }
        public static string GetItem { get; set; }
        public static string GetItems { get; set; }
        public static string GetImportItems { get; set; }

        public static string SaveCustomer { get; set; }
        public static string SavePurchase { get; set; }
        public static string SaveStockMaster{ get; set; }
        public static string SaveStockItems{ get; set; }
        public static string SaveSales{ get; set; }
        public static string UpdateImportItems { get; set; }
    }

    public class APIResponseEntity
    {
        public string resultCd { get; set; }
        public string resultMsg { get; set; }
        public object resultDt { get; set; }
        public object data { get; set; }
    }
}
