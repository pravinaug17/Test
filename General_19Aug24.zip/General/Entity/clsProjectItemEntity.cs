﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace General.Classes
{
    public class clsProjectItemEntity
    {
        public string ItemMaster__c { get; set; }
        public string Item_Description__c { get; set; }
        public string Project_Name__c { get; set; }
        public string Project_Execution_Name__c { get; set; }
        public string Group_Code__c { get; set; }
        public string Item_Group_Name__c { get; set; }
        public string SO_Section_Code__c { get; set; }
        public string SO_Section_Name__c { get; set; }
        public string SO_Sub_Section_Code__c { get; set; }
        public string SO_Sub_Section_Name__c { get; set; }
        public string BOQ_Code__c { get; set; }
        public string BOQ_Detailed_Description__c { get; set; }
        public string Color__c { get; set; }
        public string Approved_Make__c { get; set; }
        public string UOM__c { get; set; }
        public string Total_BOQ_Quantity__c { get; set; }
        public string Rate__c { get; set; }
        public string SAP_Item_Code__c { get; set; }
        public string Unique_Id__c { get; set; }
        public string Base_Price__c { get; set; }
        public string Basic_Total__c { get; set; }
        public bool SF_SAP_Check__c { get; set; }
    }
}
