﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace General.Classes
{
    public class clsPostPOEntity
    {
        public string DocEntry { get; set; }
        public string DocNum { get; set; }
        public string SeriesName { get; set; }
        public string CardCode { get; set; }
        public string Attachment { get; set; }
        public string POCreationDate { get; set; }
        public string BillTo { get; set; }
        public string ShipTo { get; set; }
        public string Comments { get; set; }
        public string SPONumber { get; set; }
        public string SapPoApprovalComments { get; set; }
        public string PRType { get; set; }
        public string VatSum { get; set; }
        public string DocTotal { get; set; }
        public string Freight { get; set; }
        public string FreightAmount { get; set; }
        public string TermsConditions { get; set; }
        public string ProjCode { get; set; }
        public string ProjName { get; set; }
        public string DocType { get; set; }
        public string DocStatus { get; set; }
        public string PRRequestId { get; set; }
        public string DocDate { get; set; }
        public string DocDueDate { get; set; }
        public string PaymentTerms { get; set; }
        public string ContactPerson { get; set; }
        public string ContactPersonNumber { get; set; }
        public string Originator { get; set; }
        public string Owner { get; set; }
        public string OwnerEmailID { get; set; }
        public string PO_Status_Update_Response__c{ get; set; }
        public List<clsPostPOLineItemEntity> LineItems { get; set; }
    }

    public class clsPostPOLineItemEntity
    {
        public string DocEntry { get; set; }
        public string LineNum { get; set; }
        public string lineItemId { get; set; }
        public string InvItemCode { get; set; }
        public string InvItemCodeSFCode { get; set; }
        public string InvItemDesc { get; set; }
        public string ItemRemarks { get; set; }
        public bool IsBatchItem { get; set; }
        public string InvOpenQty { get; set; }
        public string Quantity { get; set; }
        public string UOM { get; set; }
        public string LineTotal { get; set; }
        public string DiscPrcnt { get; set; }
        public string PriceBefDi { get; set; }
        public string Taxcode { get; set; }
        public string TaxPercentage { get; set; }
        public string HSN { get; set; }
        public string GTotal { get; set; }
        public string InvColour { get; set; }
        public string InvMake { get; set; }
        public string SectionCode { get; set; }
        public string SectionName { get; set; }
        public string SubSectionCode { get; set; }
        public string SubSectionName { get; set; }
        public string BOQCode { get; set; }
        public string BOQDesc { get; set; }
        public string GroupCode { get; set; }
        public string DocType { get; set; }
        public string UnitPrice { get; set; }
        public string LastpurPrice { get; set; }
        public string LineStatus { get; set; }
    }

}
