﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Header;

namespace General.Classes
{
    public class clsImportItemEntity
    {
        public string taskCd { get; set; }
        public string dclDe { get; set; }
        public int itemSeq { get; set; }
        public string dclNo { get; set; }
        public string hsCd { get; set; }
        public string itemNm { get; set; }
        public string imptItemsttsCd { get; set; }
        public string orgnNatCd { get; set; }
        public string exptNatCd { get; set; }
        public string pkg { get; set; }
        public string pkgUnitCd { get; set; }
        public double qty { get; set; }
        public string qtyUnitCd { get; set; }
        public string totWt { get; set; }
        public string  netWt { get; set; }
        public string agntNm { get; set; }
        public string invcFcurAmt { get; set; }
        public string invcFcurCd { get; set; }
        public double invcFcurExcrt { get; set; }
    }
     

    public class clsImportGetItemResponseEntity
    {
        public string resultCd { get; set; }
        public string resultMsg { get; set; }
        public object resultDt { get; set; }
        public clsImportItemData data { get; set; }
    }

    public class clsImportItemData
    {
        public List<clsImportItemEntity> itemList { get; set; }
    }
}
