﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Header;

namespace General.Classes
{
    public class clsUpdateImportItemEntity
    {
        public string tpin { get; set; }
        public string bhfId { get; set; }
        public string taskCd { get; set; }
        public string dclDe { get; set; }
        public List<clsUpdateImportItemList> importItemList { get; set; }
    }

    public class clsUpdateImportItemList
    {
        public int itemSeq { get; set; }
        public string hsCd { get; set; }
        public string imptItemSttsCd { get; set; }
        public string itemClsCd { get; set; }
        public string itemCd { get; set; }
        public string remark { get; set; }
        public string modrNm { get; set; }
        public string modrId { get; set; }
    }


}
