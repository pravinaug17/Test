using System;
using System.Collections.Generic;
using System.Text;

namespace General.Classes
{
    class clsVariables
    {

        #region Global Variable
        private static string sServer;
        private static string sDbName;
        private static string sDbUser;
        private static string sDbPass;
        private static string sDepartment;
        private static string sDocEntry;
        private static string sBaseFormUID;
        private static bool oboolCFLSelected;
        private static int iRowNo, iColNo;
        private static SAPbouiCOM.Form oBaseForm;
        private static string sdraftDocEntry;
        private static string sIsNewDraft;
        private static string sSalesForceUrl;
        private static string sToken;


        #endregion

        # region Login Information

        public static string Server
        {
            get { return sServer; }
            set { sServer = value; }
        }

        public static string DbName
        {
            get { return sDbName; }
            set { sDbName = value; }
        }

        public static string DbUser
        {
            get { return sDbUser; }
            set { sDbUser = value; }
        }

        public static string DbPass
        {
            get { return sDbPass; }
            set { sDbPass = value; }
        }

        #endregion

        #region Variables

        public static string BaseFormUID
        {
            get { return sBaseFormUID; }
            set { sBaseFormUID = value; }
        }

        public static string Token
        {
            get { return sToken; }
            set { sToken = value; }
        }

        public static string SalesForceUrl
        {
            get { return sSalesForceUrl; }
            set { sSalesForceUrl = value; }
        }

        public static string Department
        {
            get { return sDepartment; }
            set { sDepartment = value; }
        }

        public static string DocEntry
        {
            get { return sDocEntry; }
            set { sDocEntry = value; }
        }

        public static bool boolCFLSelected
        {
            get { return oboolCFLSelected; }
            set { oboolCFLSelected = value; }
        }

        public static SAPbouiCOM.DataTable stuffDataTable { get; set; }

        public static int RowNo
        {
            get { return iRowNo; }
            set { iRowNo = value; }
        }
        public static int ColNo
        {
            get { return iColNo; }
            set { iColNo = value; }
        }

        public static SAPbouiCOM.Form BaseForm
        {
            get { return oBaseForm; }
            set { oBaseForm = value; }
        }

        public static string DraftDocEntry
        {
            get { return sdraftDocEntry; }
            set { sdraftDocEntry = value; }
        }

        public static string IsNewDraft
        {
            get { return sIsNewDraft; }
            set { sIsNewDraft = value; }
        }
        #endregion

    }
}
