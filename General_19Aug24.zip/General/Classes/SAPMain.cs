using General;
using General.Classes;
using General.Extensions;
using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using SAPbouiCOM;
using System;
using System.Reflection;

namespace General.Classes
{
    class SAPMain : Connection
    {
        public static ILog logger;

        #region Variables

        clsCommon objclsComman = new clsCommon();

        clsItemMaster _clsItemMaster = new clsItemMaster();
        clsBPMaster _clsBPMaster = new clsBPMaster();

        clsPortalItems _clsPortalItems = new clsPortalItems();
        clsPushBulkItems _clsPushBulkItems = new clsPushBulkItems();
        clsImportItems _clsImportItems = new clsImportItems();

        clsAPInvoice _clsAPInvoice = new clsAPInvoice();
        clsAPCreditInvoice _clsAPCreditInvoice = new clsAPCreditInvoice();

        clsSalesInvoice _clsSalesInvoice = new clsSalesInvoice();
        clsSalesCreditInvoice _clsSalesCreditInvoice = new clsSalesCreditInvoice();

        clsIT _clsIT = new clsIT();

        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();
            PrepareMenus();
            PrepareEvents();
            objclsComman.GetAPIConfig();
        }

        private void PrepareMenus()
        {
            logger.DebugFormat("> {0}", nameof(PrepareMenus));
            // 8192 - System Initialisation
            // 43520 - Main Menu
            objclsComman.AddMenu(BoMenuType.mt_STRING, "8192", "UDO", "Create UDO", 5);
            objclsComman.AddMenu(BoMenuType.mt_POPUP, "43520", "CForms", "Custom Forms", 20);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "CForms", clsPortalItems.formMenuUID, clsPortalItems.formTitle, 1);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "CForms", clsPushBulkItems.formMenuUID, clsPushBulkItems.formTitle, 2);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "CForms", clsImportItems.formMenuUID, clsImportItems.formTitle, 3);
        }

        private void RemoveMenusFromSAP()
        {

        }

        /// <summary>
        /// Create Event Handler 
        /// </summary>
        private void PrepareEvents()
        {
            logger.DebugFormat("> {0} ", nameof(PrepareEvents));
            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
            oApplication.LayoutKeyEvent += new _IApplicationEvents_LayoutKeyEventEventHandler(oApplication_LayoutKeyEvent);
        }

        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Standard Forms
                if (pVal.FormTypeEx == clsItemMaster.formMenuUID)
                {
                    _clsItemMaster.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsBPMaster.formMenuUID)
                {
                    _clsBPMaster.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsAPInvoice.formMenuUID)
                {
                    _clsAPInvoice.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsAPCreditInvoice.formMenuUID)
                {
                    _clsAPCreditInvoice.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsSalesInvoice.formMenuUID)
                {
                    _clsSalesInvoice.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsSalesCreditInvoice.formMenuUID)
                {
                    _clsSalesCreditInvoice.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsIT.formMenuUID)
                {
                    _clsIT.ItemEvent(ref pVal, out BubbleEvent);
                }
                #endregion

                else if (pVal.FormTypeEx == clsPortalItems.formMenuUID)
                {
                    _clsPortalItems.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsPushBulkItems.formMenuUID)
                {
                    _clsPushBulkItems.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsImportItems.formMenuUID)
                {
                    _clsImportItems.ItemEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            SAPbouiCOM.Form oForm = null;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }

                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == "UDO")
                    {
                        oApplication.StatusBar.SetText("Please wait....", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        objclsComman.CreateDataBase();
                        oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    }
                }

                #region Forms
                if (pVal.MenuUID == clsPortalItems.formMenuUID || (oForm != null && oForm.TypeEx == clsPortalItems.formMenuUID))
                {
                    _clsPortalItems.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == clsPushBulkItems.formMenuUID || (oForm != null && oForm.TypeEx == clsPushBulkItems.formMenuUID))
                {
                    _clsPushBulkItems.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == clsImportItems.formMenuUID || (oForm != null && oForm.TypeEx == clsImportItems.formMenuUID))
                {
                    _clsImportItems.MenuEvent(ref pVal, out BubbleEvent);
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.FormTypeEx == clsItemMaster.formMenuUID)
                {
                    _clsItemMaster.FormDataEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsBPMaster.formMenuUID)
                {
                    _clsBPMaster.FormDataEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == clsIT.formMenuUID)
                {
                    _clsIT.FormDataEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            try
            {
                switch (EventType)
                {
                    case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                        oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany);
                        RemoveMenusFromSAP();
                        System.Windows.Forms.Application.Exit();
                        break;

                    case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                        oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Company changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                        System.Windows.Forms.Application.Exit();
                        break;

                    case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                        oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Server Terminition Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                        System.Windows.Forms.Application.Exit();
                        break;
                    case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                        oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Language changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                        System.Windows.Forms.Application.Exit();
                        break;
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_LayoutKeyEvent(ref LayoutKeyInfo eventInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }
        #endregion

        #region Methods

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion
    }
}
