﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace WebDAL.Helper
{
    public static class ConvertDatatableToList
    {
        public static List<T> ConvertToList<T>(DataTable datatable) where T : new()
        {
            List<T> Temp = new List<T>();
            try
            {
                List<string> columnsNames = new List<string>();
                foreach (DataColumn DataColumn in datatable.Columns)
                    columnsNames.Add(DataColumn.ColumnName);
                Temp = datatable.AsEnumerable().ToList().ConvertAll<T>(row => getObject<T>(row, columnsNames));
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }


        public static T ConvertToEntity<T>(DataTable datatable) where T : new()
        {
            T Temp = new T();
            try
            {
                List<string> columnsNames = new List<string>();
                foreach (DataColumn DataColumn in datatable.Columns)
                    columnsNames.Add(DataColumn.ColumnName);
                Temp = datatable.AsEnumerable().ToList().ConvertAll<T>(row => getObject<T>(row, columnsNames)).FirstOrDefault();
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }

        public static T getObject<T>(DataRow row, List<string> columnsName) where T : new()
        {
            T obj = new T();
            try
            {
                string columnname = "";
                string value = "";
                PropertyInfo[] Properties;
                Properties = typeof(T).GetProperties();
                foreach (PropertyInfo objProperty in Properties)
                {
                    try
                    {
                        columnname = columnsName.Find(name => name.ToLower() == objProperty.Name.ToLower());
                        if (!string.IsNullOrEmpty(columnname))
                        {
                            value = row[columnname].ToString();
                            if (!string.IsNullOrEmpty(value))
                            {
                                if (Nullable.GetUnderlyingType(objProperty.PropertyType) != null)
                                {
                                    value = row[columnname].ToString().Replace("$", "").Replace(",", "");
                                    objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(Nullable.GetUnderlyingType(objProperty.PropertyType).ToString())), null);
                                }
                                else
                                {
                                    value = row[columnname].ToString();
                                    objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(objProperty.PropertyType.ToString())), null);
                                }
                            }
                        }
                    }
                    catch { }
                }
                return obj;
            }
            catch
            {
                return obj;
            }
        }

        public static T ConvertRecordSetToEntity<T>(SAPbobsCOM.Recordset oRs) where T : new()
        {
            T Temp = new T();
            try
            {
                List<string> columnsNames = new List<string>();
                for (int i = 0; i < oRs.Fields.Count; i++)
                {
                    columnsNames.Add(oRs.Fields.Item(i).Name);
                }
                Temp = getObjectFromRecordset<T>(oRs, columnsNames);
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }

        public static List<T> ConvertRecordSetToList<T>(SAPbobsCOM.Recordset oRs) where T : new()
        {
            List<T> Temp = new List<T>();
            try
            {
                List<string> columnsNames = new List<string>();
                for (int i = 0; i < oRs.Fields.Count; i++)
                {
                    columnsNames.Add(oRs.Fields.Item(i).Name);
                }
                Temp = getObjectListFromRecordset<T>(oRs, columnsNames);
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }

        public static T getObjectFromRecordset<T>(SAPbobsCOM.Recordset row, List<string> columnsName) where T : new()
        {
            T obj = new T();
            try
            {
                string columnname = "";
                string value = "";
                PropertyInfo[] Properties;
                Properties = typeof(T).GetProperties();
                foreach (PropertyInfo objProperty in Properties)
                {
                    try
                    {
                        columnname = columnsName.Find(name => name.ToLower() == objProperty.Name.ToLower());
                        if (!string.IsNullOrEmpty(columnname))
                        {
                            value = row.Fields.Item(columnname).Value.ToString();
                            if (!string.IsNullOrEmpty(value))
                            {
                                if (Nullable.GetUnderlyingType(objProperty.PropertyType) != null)
                                {
                                    value = row.Fields.Item(columnname).Value.ToString().Replace("$", "").Replace(",", "");
                                    objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(Nullable.GetUnderlyingType(objProperty.PropertyType).ToString())), null);
                                }
                                else
                                {
                                    value = row.Fields.Item(columnname).Value.ToString();
                                    objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(objProperty.PropertyType.ToString())), null);
                                }
                            }
                        }
                    }
                    catch { }
                }
                return obj;
            }
            catch
            {
                return obj;
            }
        }


        public static List<T> getObjectListFromRecordset<T>(SAPbobsCOM.Recordset oRs, List<string> columnsName) where T : new()
        {
            List<T> objList = new List<T>();
            try
            {
                string columnname = "";
                string value = "";
                PropertyInfo[] Properties;
                Properties = typeof(T).GetProperties();
                
                T obj = new T();
                
                oRs.MoveFirst();
                while (!oRs.EoF)
                {
                    obj = new T();
                    foreach (PropertyInfo objProperty in Properties)
                    {
                        try
                        {
                            columnname = columnsName.Find(name => name.ToLower() == objProperty.Name.ToLower());
                            if (!string.IsNullOrEmpty(columnname))
                            {
                                value = oRs.Fields.Item(columnname).Value.ToString();
                                if (!string.IsNullOrEmpty(value))
                                {
                                    if (Nullable.GetUnderlyingType(objProperty.PropertyType) != null)
                                    {
                                        value = oRs.Fields.Item(columnname).Value.ToString().Replace("$", "").Replace(",", "");
                                        objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(Nullable.GetUnderlyingType(objProperty.PropertyType).ToString())), null);
                                    }
                                    else
                                    {
                                        value = oRs.Fields.Item(columnname).Value.ToString();
                                        objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(objProperty.PropertyType.ToString())), null);
                                    }
                                }
                            }
                        }
                        catch { }
                    }
                    objList.Add(obj);
                    oRs.MoveNext();
                }
                return objList;
            }
            catch
            {
                return objList;
            }
        }

        public static List<T> ConvertSAPDataTableToList<T>(SAPbouiCOM.DataTable oDataTable) where T : new()
        {
            List<T> Temp = new List<T>();
            try
            {
                List<string> columnsNames = new List<string>();
                for (int i = 0; i < oDataTable.Columns.Count; i++)
                {
                    columnsNames.Add(oDataTable.Columns.Item(i).Name);
                }
                Temp = getObjectFromSAPDataTable<T>(oDataTable, columnsNames);
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }

        public static List<T> getObjectFromSAPDataTable<T>(SAPbouiCOM.DataTable row, List<string> columnsName) where T : new()
        {
            List<T> objList = new List<T>();
            T obj = new T();
            try
            {
                string columnname = "";
                string value = "";
                PropertyInfo[] Properties;
                Properties = typeof(T).GetProperties();

                for (int i = 0; i < row.Rows.Count; i++)
                {
                    foreach (PropertyInfo objProperty in Properties)
                    {
                        try
                        {
                            columnname = columnsName.Find(name => name.ToLower() == objProperty.Name.ToLower());
                            if (!string.IsNullOrEmpty(columnname))
                            {
                                value = row.GetValue(columnname, i).ToString(); // row.Fields.Item(columnname).Value.ToString();
                                if (!string.IsNullOrEmpty(value))
                                {
                                    if (Nullable.GetUnderlyingType(objProperty.PropertyType) != null)
                                    {
                                        value = value.ToString().Replace("$", "").Replace(",", "");
                                        objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(Nullable.GetUnderlyingType(objProperty.PropertyType).ToString())), null);
                                    }
                                    else
                                    {
                                        objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(objProperty.PropertyType.ToString())), null);
                                    }
                                }
                            }
                        }
                        catch { }
                    }
                    objList.Add(obj);
                }
            }
            catch
            {
            }
            return objList;
        }

    }
}
