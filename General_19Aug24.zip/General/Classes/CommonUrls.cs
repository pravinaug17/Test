﻿namespace General.Classes
{ 
    public static class CommonUrls
    {
        public const string ItemMasterUrl = "Item_Master__c";
        public const string ProjectItemMasterUrl = "Project_Items__c";
        public const string VendorMasterUrl = "Vendor_Master__c";
        
        public const string POUrl = "postOpenPO";
        public const string PODraftUrl = "postDraftPO";
        public const string BOMUrl = "GetBOMDataFromSAP";

    }
}
 