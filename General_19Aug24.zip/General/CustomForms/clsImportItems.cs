using General.Classes;
using SAPbouiCOM;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Linq;
using System.Data.OleDb;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using WebDAL.Helper;

namespace General
{
    class clsImportItems : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();
        SAPbouiCOM.Form oForm;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        SAPbouiCOM.DBDataSource oDbDataSource;
        public const string formMenuUID = "IMPITEMS";
        public const string formTitle = "Import Items";
        public const string headerTable = "OITM";
        const string gridUID = "grd1";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "btLoad")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                List<clsImportItemEntity> itemList = CallGetItems();
                                SaveData(itemList);
                                FillGrid(oForm);
                            }
                            else if (pVal.ItemUID == "btUpdate")
                            {
                                System.Threading.Thread oThread = new System.Threading.Thread(new System.Threading.ThreadStart(CallUpdateImportItems));
                                oThread.SetApartmentState(System.Threading.ApartmentState.STA);
                                oThread.Start();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_ITEM")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("ItemCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {


                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID)
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
        }

        #endregion

        public void LoadForm(string menuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    oForm = objclsCommon.LoadXML(string.Empty, menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void FillGrid_Old(SAPbouiCOM.Form oForm, List<clsImportItemEntity> itemList)
        {
            oForm.Freeze(true);
            try
            {
                SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
                PropertyInfo[] Properties;

                SAPbouiCOM.DataTable oDT = null;
                try
                {
                    oDT = oForm.DataSources.DataTables.Add(gridUID);
                }
                catch
                {
                    oDT = oForm.DataSources.DataTables.Item(gridUID);
                }
                try
                {
                    Properties = typeof(clsImportItemEntity).GetProperties();
                    foreach (PropertyInfo objProperty in Properties)
                    {
                        oDT.Columns.Add(objProperty.Name, SAPbouiCOM.BoFieldsType.ft_AlphaNumeric, 200);
                    }
                }
                catch { }
                oDT.Rows.Clear();
                Properties = typeof(clsImportItemEntity).GetProperties();

                int j = 0;
                foreach (clsImportItemEntity item in itemList)
                {
                    oDT.Rows.Add();
                    for (int i = 0; i < Properties.Length; i++)
                    {
                        try
                        {
                            string name = Properties[i].Name;
                            oDT.SetValue(name, j, Properties[i].GetValue(item, null));
                        }
                        catch { }
                    }
                    j++;
                }

                oGrid.DataTable = oDT;
                for (int i = 0; i < oGrid.Columns.Count; i++)
                {
                    oGrid.Columns.Item(i).Editable = false;
                }

                SAPbouiCOM.EditTextColumn oColumns = (SAPbouiCOM.EditTextColumn)oGrid.Columns.Item("itemCd");
                oColumns.LinkedObjectType = "4";
                oApplication.StatusBar.SetText("Operation completed", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Fill Grid: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
            }
            oForm.Freeze(false);

        }


        private List<clsImportItemEntity> CallGetItems()
        {
            oForm = oApplication.Forms.ActiveForm;
            oApplication.StatusBar.SetText("Please wait...getting to data", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            clsGetItemReqeustEntity _entity = new clsGetItemReqeustEntity();
            _entity.tpin = APIEntity.TPin;
            _entity.bhfId = APIEntity.BhfId;
            _entity.lastReqDt = "20231120193115";
            return objclsCommon.GetImportItems(_entity);
        }

        private void SaveData(List<clsImportItemEntity> itemList)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < itemList.Count; i++)
            {
                sb = new StringBuilder();
                sb.Append("SELECT MAX(Cast(Code as Numeric(19,0)))  FROM \"@ZRAIMP\"");
                string code = objclsCommon.SelectRecord(sb.ToString());
                double dblCode = code == string.Empty ? 0 : Convert.ToDouble(code);
                dblCode = dblCode + 1;

                sb = new StringBuilder();
                sb.Append("SELECT U_TaskCd FROM \"@ZRAIMP\" WHERE U_TaskCd ='" + itemList[i].taskCd + "' AND U_ItemSeq ='" + itemList[i].itemSeq + "'");
                string taskcode = objclsCommon.SelectRecord(sb.ToString());
                if (taskcode == string.Empty)
                {
                    //sb = new StringBuilder();
                    //sb.Append("SELECT ItemCode FROM \"OITM\" WHERE ItemName ='" + itemList[i].itemNm + "'");
                    //string itemcode = objclsCommon.SelectRecord(sb.ToString());

                    sb = new StringBuilder();
                    sb.Append("INSERT INTO \"@ZRAIMP\"(Code,Name,U_TaskCd,U_DclDe,U_HsCd,U_ImpISC,U_ItemNm,U_ItemSeq) VALUES ( ");
                    sb.Append(" '" + dblCode + "','" + dblCode + "','" + itemList[i].taskCd + "','" + itemList[i].dclDe + "', ");
                    sb.Append(" '" + itemList[i].hsCd + "','" + itemList[i].imptItemsttsCd + "','" + itemList[i].itemNm + "','" + itemList[i].itemSeq + "' ");
                    sb.Append(" ) ");
                    objclsCommon.SelectRecord(sb.ToString());
                }

            }
        }

        private void FillGrid(SAPbouiCOM.Form oForm)
        {
            oForm.Freeze(true);
            try
            {
                SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;

                SAPbouiCOM.DataTable oDT = null;
                try
                {
                    oDT = oForm.DataSources.DataTables.Add(gridUID);
                }
                catch
                {
                    oDT = oForm.DataSources.DataTables.Item(gridUID);
                }
                oDT.Rows.Clear();
                string query = "EXEC Proc_Get_ImportItems 'A',''";
                objclsCommon.FillGrid(oForm.UniqueID, gridUID, gridUID, query);
                oGrid.DataTable = oDT;
                for (int i = 0; i < oGrid.Columns.Count; i++)
                {
                    oGrid.Columns.Item(i).Editable = false;
                }

                oApplication.StatusBar.SetText("Operation completed", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Fill Grid: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
            }
            oForm.Freeze(false);

        }

        private void CallUpdateImportItems()
        {
            oForm = oApplication.Forms.ActiveForm;
            oApplication.StatusBar.SetText("Please wait...getting to data", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            string query = "EXEC Proc_Get_ImportItems 'D',''";
            oRs = objclsCommon.returnRecord(query);
            while (!oRs.EoF)
            {
                string taskcode = oRs.Fields.Item("taskCd").Value;
                clsUpdateImportItemEntity _entity = new clsUpdateImportItemEntity();
                query = "EXEC Proc_Get_ImportItems 'R','" + taskcode + "'";
                SAPbobsCOM.Recordset oRsRows = objclsCommon.returnRecord(query);
                List<clsUpdateImportItemList> list = ConvertDatatableToList.ConvertRecordSetToList<clsUpdateImportItemList>(oRsRows);
                _entity.tpin = APIEntity.TPin;
                _entity.bhfId = APIEntity.BhfId;
                _entity.taskCd = oRs.Fields.Item("taskCd").Value;
                _entity.dclDe = oRs.Fields.Item("dclDe").Value;
                _entity.importItemList = list;
                bool isImportSuccess = objclsCommon.PostUpdateImportItems(_entity);
                if (isImportSuccess == true)
                {
                    for (int i = 0; i < list.Count; i++)
                    {
                        string itemcode = list[i].itemCd;
                        PushSaveStockMaster(itemcode);
                    }
                }
                oRs.MoveNext();
            }
        }

        private void PushSaveStockMaster(string itemcode)
        {
            oForm = oApplication.Forms.ActiveForm;

            string query = "SELECT OnHand FROM OITM WHERE ItemCode = '" + itemcode + "'";
            string onHand = objclsCommon.SelectRecord(query);
            onHand = onHand == string.Empty ? "0" : onHand;
            clsSaveStockMasterEntity _entity = new clsSaveStockMasterEntity();
            _entity.tpin = APIEntity.TPin;
            _entity.bhfId = APIEntity.BhfId;
            _entity.regrNm = "manager";
            _entity.regrId = "1";
            _entity.modrNm = "manager";
            _entity.modrId = "1";
            clsSaveStockMasterItemEntity _entityRow = new clsSaveStockMasterItemEntity();
            _entityRow.rsdQty = double.Parse(onHand);
            _entityRow.itemCd = itemcode;

            List<clsSaveStockMasterItemEntity> _entityRowsList = new List<clsSaveStockMasterItemEntity>();
            _entityRowsList.Add(_entityRow);
            _entity.stockItemList = _entityRowsList;
            objclsCommon.PostSaveStockMaster(_entity,"UpdateImport");
        }

    }
}