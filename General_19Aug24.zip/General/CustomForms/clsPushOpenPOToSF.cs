﻿using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Xml;
using System.Collections;
using System.Data;
using System.Net;
using System.Data.SqlClient;
using System.CodeDom;
using System.Security.Policy;
using System.Collections.Specialized;
using General.Classes;
using DocumentFormat.OpenXml.Office2010.PowerPoint;

namespace General
{
    class clsPushOpenPOToSF : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;

        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formTypeEx = "OPENPO";
        public const string formMenuUID = "OPENPO";
        public const string formTitle = "Open PO - Push To Salesforce";
        const string gridDocumentsUID = "grd1";
        public const string headerTable = "OPOR";
        public const string rowTable = "POR1";
        public const string freighTable = "POR3";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "btLoad")
                            {
                                FillGrid();
                            }
                            else if (pVal.ItemUID == "btPush")
                            {
                                int k = oApplication.MessageBox("Do you want to proceed?", 1, "Yes", "No", "");
                                if (k == 1)
                                {
                                    System.Threading.Thread oThread = new System.Threading.Thread(new System.Threading.ThreadStart(PushToSalesForce));
                                    oThread.SetApartmentState(System.Threading.ApartmentState.STA);
                                    oThread.Start();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID)
                    {
                        LoadForm();
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm()
        {
            try
            {
                string FormID;
                if (objclsCommon.FormAlreadyExist(formMenuUID, out FormID) == true)
                {
                    oForm = oApplication.Forms.Item(FormID);
                    oForm.Select();
                    return;
                }
                oForm = objclsCommon.LoadForm(formMenuUID, formMenuUID, BoFormModality.fm_None);
                oForm.DataSources.UserDataSources.Add("FromDate", BoDataType.dt_DATE, 20);
                oEdit = oForm.Items.Item("FromDate").Specific;
                oEdit.DataBind.SetBound(true, "", "FromDate");
                DateTime dateTime = DateTime.Now.Date.AddMonths(-1);
                DateTime dateLastMonth = new DateTime(dateTime.Year, dateTime.Month, 1);
                oEdit.String = dateLastMonth.ToString("ddMMyy");
                oForm.DataSources.UserDataSources.Add("ToDate", BoDataType.dt_DATE, 20);
                oEdit = oForm.Items.Item("ToDate").Specific;
                oEdit.DataBind.SetBound(true, "", "ToDate");
                oEdit.String = "t";
                oForm.Items.Item("btLoad").Click(BoCellClickType.ct_Regular);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FillGrid()
        {
            oApplication.StatusBar.SetText("Please wait", BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);
            oForm = oApplication.Forms.ActiveForm;
            string fromDate = oForm.DataSources.UserDataSources.Item("FromDate").ValueEx;
            string toDate = oForm.DataSources.UserDataSources.Item("ToDate").ValueEx;
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT 'N' \"Selection\",ROW_NUMBER() OVER (ORDER BY T0.\"DocDate\") \"RowNo\",T0.\"DocEntry\",T0.\"DocNum\", ");
            sbQuery.Append(" T0.\"CardCode\",T0.\"CardName\",T0.\"DocDate\",T0.\"DocTotal\",MAX(T1.\"DraftEntry\") DraftEntry ");
            sbQuery.Append(" FROM OPOR T0 ");
            sbQuery.Append(" LEFT JOIN OWDD T1 ON T0.\"DocEntry\"= T1.\"DocEntry\" AND T0.\"ObjType\" =T1.\"ObjType\" ");
            sbQuery.Append(" WHERE ");
            sbQuery.Append(" T0.\"CreateDate\" >= '" + fromDate + "' AND T0.\"CreateDate\" <= '" + toDate + "' ");
            sbQuery.Append(" AND T0.\"U_SFID\" IS NULL ");
            sbQuery.Append(" AND T0.\"DocStatus\" = 'O' ");

            //sbQuery.Append(" T0.\"DocEntry\" IN (2799,2813,3036,3661,3530,3554,3443,3660,3441,3453,3451,3329,3399,3458,3452,3483,3662,3537,3507) ");
            //sbQuery.Append(" T0.\"DocEntry\" IN (3536,3534,3559,2793,2794,2800,2957,2959,2804,2811,2810,2952,2956,3139,2797,3303,2814,2802,2798,2803,3210,2801,2955,3290,3065,2809,3219,3209,3143,3285,3141,3175,3295,3298) ");
            sbQuery.Append(" GROUP BY T0.\"DocEntry\",T0.\"DocNum\", ");
            sbQuery.Append(" T0.\"CardCode\",T0.\"CardName\",T0.\"DocDate\",T0.\"DocTotal\" ");
            sbQuery.Append(" ORDER BY T0.\"DocDate\" ");

            oForm.Freeze(true);
            try
            {
                SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridDocumentsUID).Specific;
                objclsCommon.FillGrid(oForm.UniqueID, gridDocumentsUID, gridDocumentsUID, sbQuery.ToString());
                for (int i = 1; i < oGrid.Columns.Count; i++)
                {
                    oGrid.Columns.Item(i).Editable = false;
                    oGrid.Columns.Item(i).TitleObject.Sortable = true;
                }
                oGrid.Columns.Item(0).Type = BoGridColumnType.gct_CheckBox;
                SAPbouiCOM.EditTextColumn oCol = (SAPbouiCOM.EditTextColumn)oGrid.Columns.Item("DocEntry");
                oCol.LinkedObjectType = "22";
                oApplication.StatusBar.SetText("Data loaded", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("FillGrid: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
            oForm.Freeze(false);
        }

        private void PushToSalesForce()
        {
            oForm = oApplication.Forms.ActiveForm;
            #region Push To SalesForce

            oApplication.StatusBar.SetText("Please wait...pushing po to sales force", BoMessageTime.bmt_Medium, BoStatusBarMessageType.smt_Success);

            clsPostPOEntity _entity = new clsPostPOEntity();
            List<clsPostPOLineItemEntity> _lineList = new List<clsPostPOLineItemEntity>();
            clsPostPOLineItemEntity _lineEntity = new clsPostPOLineItemEntity();
            SAPbouiCOM.DataTable dataTable = oForm.DataSources.DataTables.Item(gridDocumentsUID);
            string additonalMessage = "Open PO added into SAP from Additional window";

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                string selected = dataTable.GetValue("Selection", i).ToString();
                if (selected == "Y")
                {
                    string docEntry = dataTable.GetValue("DocEntry", i).ToString();
                    string docNum = dataTable.GetValue("DocNum", i).ToString();

                    oApplication.StatusBar.SetText("Please wait....processing docnum: " + docNum, BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);
                }
            }

            #endregion

            oApplication.StatusBar.SetText("Operation completed", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            FillGrid();
        }

    }
}

