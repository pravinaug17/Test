﻿using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Xml;
using System.Collections;
using System.Data;
using System.Net;
using System.Data.SqlClient;
using System.CodeDom;
using System.Security.Policy;
using System.Collections.Specialized;
using General.Classes;
using DocumentFormat.OpenXml.Office2010.PowerPoint;

namespace General
{
    class clsPushDraftToSF : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();
        SAPbouiCOM.Form oForm;

        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formTypeEx = "DRAFTPO";
        public const string formMenuUID = "DRAFTPO";
        public const string formTitle = "Draft PO - Push To Salesforce";
        const string gridDocumentsUID = "grd1";
        public const string headerTable = "ODRF";
        public const string rowTable = "DRF1";
        public const string freighTable = "DRF3";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "btPush")
                            {

                                System.Threading.Thread oThread = new System.Threading.Thread(new System.Threading.ThreadStart(PushToSalesForce));
                                oThread.SetApartmentState(System.Threading.ApartmentState.STA);
                                oThread.Start();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID)
                    {
                        LoadForm();
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm()
        {
            try
            {
                string FormID;
                if (objclsCommon.FormAlreadyExist(formMenuUID, out FormID) == true)
                {
                    oForm = oApplication.Forms.Item(FormID);
                    oForm.Select();
                    return;
                }
                oForm = objclsCommon.LoadForm(formMenuUID, formMenuUID, BoFormModality.fm_None);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void PushToSalesForce()
        {
            oForm = oApplication.Forms.ActiveForm;
            string draftKey = oForm.DataSources.DBDataSources.Item("ODRF").GetValue("DocEntry", 0).Trim();
            if (draftKey != string.Empty)
            {
                #region Push To SalesForce

                oApplication.StatusBar.SetText("Please wait...pushing draft po to sales force", BoMessageTime.bmt_Medium, BoStatusBarMessageType.smt_Success);

                #endregion
            }
            oApplication.StatusBar.SetText("Operation completed", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
        }

    }
}

