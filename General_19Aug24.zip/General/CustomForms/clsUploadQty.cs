using DocumentFormat.OpenXml.VariantTypes;
using General.Classes;
using General.Extensions;
using SAPbouiCOM;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Configuration;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace General
{
    class clsUploadQty : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();
        SAPbouiCOM.Form oForm;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formMenuUID = "UPLOADQTY";
        public const string formTitle = "Upload RA Bill Qty";
        public const string headerTable = "@RABILL";
        public const string rowTable = "@RABILL1";

        SAPbouiCOM.DBDataSource oDbDataSource = null;

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "btExp")
                            {
                                System.Threading.Thread oThread = new System.Threading.Thread(new System.Threading.ThreadStart(ExportToExcel));
                                oThread.SetApartmentState(System.Threading.ApartmentState.STA);
                                oThread.Start();
                            }
                            else if (pVal.ItemUID == "btPost")
                            {
                                System.Threading.Thread oThread = new System.Threading.Thread(new System.Threading.ThreadStart(LoadExcel));
                                oThread.SetApartmentState(System.Threading.ApartmentState.STA);
                                oThread.Start();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_RABILL")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("DocEntry", 0, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue("U_CardName", 0).ToString());
                            }
                        }
                        #endregion

                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ItemUID == "DocEntry")
                            {
                                oForm = oApplication.Forms.ActiveForm;
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                string cardName = objclsCommon.SelectRecord("SELECT \"U_CardName\" FROM \"" + headerTable + "\" WHERE \"DocEntry\" = '" + docEntry + "'  ");
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_CardName", 0, cardName);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD
                        || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Code", 0).Trim();
                        sbQuery = new StringBuilder();
                        sbQuery.Append("DELETE FROM \"" + rowTable + "\" WHERE \"Code\"='" + code + "' AND \"U_ItemCode\" IS NULL");
                        objclsCommon.SelectRecord(sbQuery.ToString());
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {


                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
        }

        #endregion

        public void LoadForm(string menuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    oForm = objclsCommon.LoadXML(string.Empty, menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void ExportToExcel()
        {
            oForm = oApplication.Forms.ActiveForm;
            try
            {
                oApplication.StatusBar.SetText("Exporting to Excel. Please wait it will take some time.", BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);
                ClosedXML.Excel.XLWorkbook wb = new ClosedXML.Excel.XLWorkbook();
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataTable.Columns.Add("LineId", typeof(System.Int32));
                dataTable.Columns.Add("Supply", typeof(System.String));
                dataTable.Columns.Add("SupplyDesc", typeof(System.String));
                dataTable.Columns.Add("Quantity", typeof(System.String));
                dataTable.Columns.Add("BOQSRNo", typeof(System.String));
                dataTable.Columns.Add("WhseQty", typeof(System.String));
                dataTable.Columns.Add("BilledQtySupply", typeof(System.String));
                dataTable.Columns.Add("BilledQtyInstallation", typeof(System.String));
                dataTable.Columns.Add("RateSupply", typeof(System.String));
                dataTable.Columns.Add("RateInstallation", typeof(System.String));
                dataTable.Columns.Add("U_TotExeSuppQty", typeof(System.String));
                dataTable.Columns.Add("U_TotExeInstalQty", typeof(System.String));

                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  T0.\"LineId\", T0.\"U_Supply\",T0.\"U_SupplyDesc\" ");
                stringBuilder.Append(" ,T0.\"U_Quantity\",T0.\"U_TotExeSuppQty\",T0.\"U_TotExeInstalQty\"  ");
                stringBuilder.Append(" ,T2.\"U_BOQSrNO\",T3.\"OnHand\",T0.\"U_SupplyPrice\",T0.\"U_InstallPrice\"  ");

                stringBuilder.Append(" FROM \"" + rowTable + "\" T0");
                stringBuilder.Append(" LEFT JOIN \"" + headerTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
                stringBuilder.Append(" LEFT JOIN RDR1 T2 ON T1.\"U_SO_Docentry\" = T2.\"DocEntry\" AND  T0.\"U_LineNum_Install\" = T2.\"LineNum\"  ");
                stringBuilder.Append(" LEFT JOIN OITW T3 ON T2.\"ItemCode\" = T3.\"ItemCode\" AND  T2.\"WhsCode\" = T3.\"WhsCode\" ");
                //stringBuilder.Append(" WHERE T0.\"DocEntry\" = '" + docEntry + "' ORDER BY T0.\"LineId\" ");
                stringBuilder.Append(" WHERE T2.\"TreeType\" != 'I' AND T0.\"DocEntry\" = '" + docEntry + "' ORDER BY T0.\"LineId\" ");
                oRs = objclsCommon.returnRecord(stringBuilder.ToString());
                int recordRecord = oRs.RecordCount;
                while (!oRs.EoF)
                {
                    System.Data.DataRow dr = dataTable.NewRow();
                    dr["LineId"] = oRs.Fields.Item("LineId").Value.ToString();
                    dr["Supply"] = oRs.Fields.Item("U_Supply").Value.ToString();
                    dr["SupplyDesc"] = oRs.Fields.Item("U_SupplyDesc").Value.ToString();
                    dr["Quantity"] = oRs.Fields.Item("U_Quantity").Value.ToString();
                    dr["U_TotExeSuppQty"] = oRs.Fields.Item("U_TotExeSuppQty").Value.ToString();
                    dr["U_TotExeInstalQty"] = oRs.Fields.Item("U_TotExeInstalQty").Value.ToString();

                    dr["BOQSRNo"] = oRs.Fields.Item("U_BOQSrNO").Value.ToString();
                    dr["WhseQty"] = oRs.Fields.Item("OnHand").Value.ToString();
                    dr["RateSupply"] = oRs.Fields.Item("U_SupplyPrice").Value.ToString();
                    dr["RateInstallation"] = oRs.Fields.Item("U_InstallPrice").Value.ToString();

                    dataTable.Rows.Add(dr);
                    oRs.MoveNext();
                }
                wb.Worksheets.Add(dataTable, "Sheet1");
                string filepath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) +  "\\ExportExcel\\" + oCompany.CompanyDB + "\\" ;
                if (!Directory.Exists(filepath))
                {
                    Directory.CreateDirectory(filepath);
                }
                string fileName = "RABill_" + docEntry.ToString();
                filepath = filepath + "\\" + fileName + ".xlsx";
                wb.SaveAs(filepath);

                oApplication.StatusBar.SetText("File exported successfully at path " + filepath, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Load Excel Error: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        private void LoadExcel()
        {
            oForm = oApplication.Forms.ActiveForm;
            try
            {
                oApplication.StatusBar.SetText("Please wait while updating records.", BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);
                string filePath = oForm.DataSources.DBDataSources.Item("OADM").GetValue("U_FilePath", 0).Trim();
                string conStr = "";
                string isHDR = "Yes";
                string extension = Path.GetExtension(filePath);

                switch (extension)
                {

                    case ".xls": //Excel 97-03  
                        conStr = ConfigurationManager.ConnectionStrings["Excel03ConString"]
                        .ConnectionString;

                        break;

                    case ".xlsx": //Excel 07  
                        conStr = ConfigurationManager.ConnectionStrings["Excel07ConString"]
                        .ConnectionString;

                        break;

                }

                conStr = String.Format(conStr, filePath, isHDR);

                OleDbConnection connExcel = new OleDbConnection(conStr);

                OleDbCommand cmdExcel = new OleDbCommand();

                OleDbDataAdapter oda = new OleDbDataAdapter();

                System.Data.DataTable dt = new System.Data.DataTable();

                cmdExcel.Connection = connExcel;

                //Get the name of First Sheet  

                connExcel.Open();

                System.Data.DataTable dtExcelSchema;

                dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();

                connExcel.Close();

                //Read Data from First Sheet  

                connExcel.Open();

                SheetName = "Sheet1$";
                //cmdExcel.CommandText = "SELECT * From [" + SheetName + "]";
                cmdExcel.CommandText = "SELECT * From [" + SheetName + "]";

                oda.SelectCommand = cmdExcel;
                oda.Fill(dt);
                connExcel.Close();

                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                StringBuilder stringBuilder = new StringBuilder();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string lineId = dt.Rows[i]["LineId"].ToString();
                    string U_TotExeSuppQty = dt.Rows[i]["U_TotExeSuppQty"].ToString();
                    string U_TotExeInstalQty = dt.Rows[i]["U_TotExeInstalQty"].ToString();
                    U_TotExeSuppQty = U_TotExeSuppQty == string.Empty ? "0": U_TotExeSuppQty;
                    U_TotExeInstalQty = U_TotExeInstalQty == string.Empty ? "0": U_TotExeInstalQty;
                    stringBuilder = new StringBuilder();
                    stringBuilder.Append(" UPDATE T0 SET ");
                    stringBuilder.Append(" \"U_TotExeSuppQty\" ='" + U_TotExeSuppQty + "',");
                    stringBuilder.Append(" \"U_TotExeInstalQty\" ='" + U_TotExeInstalQty + "' ");
                    stringBuilder.Append(" FROM \"" + rowTable + "\" T0 ");
                    stringBuilder.Append(" WHERE \"DocEntry\" = '" + docEntry + "' AND \"LineId\" = '" + lineId + "' ");
                    objclsCommon.SelectRecord(stringBuilder.ToString());
                }
                oApplication.StatusBar.SetText("Operation completed ", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Load Excel Error: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }
    }
}