using DocumentFormat.OpenXml.VariantTypes;
using DocumentFormat.OpenXml.Wordprocessing;
using General.Classes;
using SAPbobsCOM;
using SAPbouiCOM;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Linq;
using System.Data.OleDb;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace General
{
    class clsPostDraftPOSAP : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        StringBuilder sbQuery = new StringBuilder();
        public const string formMenuUID = "POSTDRAFT";
        public const string formTitle = "Post Draft-Approved in SalesForce";
        public const string headerTable = "OQUT";
        const string gridUID = "grd1";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "btLoad")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                FillGrid(oForm);
                            }
                            else if (pVal.ItemUID == "btPost")
                            {
                                //SAPbobsCOM.Documents oDocDraft = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oDrafts);
                                //oDocDraft.GetByKey(680);
                                //int i = oDocDraft.SaveDraftToDocument();
                                //if (i != 0)
                                //{
                                //    string error = oCompany.GetLastErrorDescription();
                                //}
                                //int k = oApplication.MessageBox("Do you want to post?", 1, "Yes", "No", "");
                                //if (k == 1)
                                //{
                                System.Threading.Thread oThread = new System.Threading.Thread(new System.Threading.ThreadStart(Post));
                                oThread.SetApartmentState(System.Threading.ApartmentState.STA);
                                oThread.Start();
                                //}
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {


                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID)
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
        }

        #endregion

        public void LoadForm(string menuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    oForm = objclsCommon.LoadXML(string.Empty, menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
                    oForm.Items.Item("btLoad").Click(BoCellClickType.ct_Regular);
                    
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void FillGrid(SAPbouiCOM.Form oForm)
        {
            try
            {
                SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
                int i = 0;

                SAPbouiCOM.DataTable oDT = null;
                try
                {
                    oDT = oForm.DataSources.DataTables.Add(gridUID);
                }
                catch
                {
                    oDT = oForm.DataSources.DataTables.Item(gridUID);
                }
                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT 'Y' \"Selection\",ROW_NUMBER() OVER (ORDER BY T0.\"DraftEntry\") \"RowNo\", ");
                sbQuery.Append(" T0.\"DraftEntry\",T0.\"Remarks\",T1.\"DocDate\",T1.\"DocStatus\" ");
                sbQuery.Append(" FROM OWDD T0  ");
                sbQuery.Append(" INNER JOIN ODRF T1 ON T0.\"DraftEntry\" = T1.\"DocEntry\"  ");
                sbQuery.Append(" WHERE T0.\"Status\" = 'Y' AND T0.\"DocEntry\" IS NULL AND T0.\"ObjType\" = '22' ");
                sbQuery.Append(" AND T1.\"CreateDate\" > '2023-06-01'  ");
                sbQuery.Append(" AND T1.\"DocStatus\" = 'O'  ");
                sbQuery.Append(" AND T1.\"U_SFID\" IS NULL ");

                oDT.ExecuteQuery(sbQuery.ToString());
                oGrid.DataTable = oDT;
                for (i = 1; i < oGrid.Columns.Count; i++)
                {
                    oGrid.Columns.Item(i).Editable = false;
                    oGrid.Columns.Item(i).TitleObject.Sortable = true;
                }
                oGrid.Columns.Item(0).Type = BoGridColumnType.gct_CheckBox;

                SAPbouiCOM.EditTextColumn oColumns = (SAPbouiCOM.EditTextColumn)oGrid.Columns.Item("DraftEntry");
                oColumns.LinkedObjectType = "112";
                oGrid.SelectionMode = BoMatrixSelect.ms_Single;
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Fill Grid: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
            }
        }

        private void Post()
        {
            oForm = oApplication.Forms.ActiveForm;
            oEdit = oForm.Items.Item("DKey").Specific;
            SAPbouiCOM.EditText oEditNext = oForm.Items.Item("test").Specific;
            SAPbouiCOM.LinkedButton linkedButton = oForm.Items.Item("lbDKey").Specific;
            SAPbouiCOM.Grid oGrid = oForm.Items.Item(gridUID).Specific;
            SAPbouiCOM.DataTable oDT = null;
            oDT = oForm.DataSources.DataTables.Item(gridUID);
            List<string> listStrings = new List<string>();
            for (int i = 0; i < oDT.Rows.Count; i++)
            {
                string selection = oDT.GetValue("Selection", i).ToString();
                if (selection == "Y")
                {
                    string draftEntry = oDT.GetValue("DraftEntry", i).ToString();
                    string isDraft = objclsCommon.SelectRecord("SELECT \"IsDraft\" FROM OWDD WHERE \"DraftEntry\"='" + draftEntry + "' AND \"IsDraft\" = 'Y' ");
                    if (isDraft == "Y")
                    {
                        listStrings.Add(draftEntry);
                        oEdit.String = draftEntry;
                        oEditNext.Active = true;
                        linkedButton.Item.Click();

                        SAPbouiCOM.Form oPOForm = oApplication.Forms.ActiveForm;
                        oPOForm.Items.Item("1").Click();
                        oPOForm.Items.Item("2").Click();
                    }
                }
            }

            string additonalMessage = "Open PO added into SAP from Additional window";
            for (int i = 0; i < listStrings.Count; i++)
            {
                try
                {
                    string draftEntry = listStrings[i].ToString();
                    sbQuery = new StringBuilder();
                    sbQuery.Append(" SELECT T0.\"DocEntry\"  ");
                    sbQuery.Append(" FROM OPOR T0 ");
                    sbQuery.Append(" LEFT JOIN OWDD T1 ON T0.\"DocEntry\"= T1.\"DocEntry\" AND T0.\"ObjType\" =T1.\"ObjType\" ");
                    sbQuery.Append(" WHERE  T1.\"DraftEntry\" = '" + draftEntry + "' ");
                    sbQuery.Append(" AND T0.\"U_SFID\" IS NULL ");
                    string docEntry = objclsCommon.SelectRecord(sbQuery.ToString());
                    if (docEntry != string.Empty)
                    {
                        oApplication.StatusBar.SetText("Please wait....processing draft entry: " + draftEntry, BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText("Pushing Open PO To Salesforce: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }

            oForm.Items.Item("2").Click(BoCellClickType.ct_Regular);
            //FillGrid(oForm);
        }
    }
}