using General.Classes;
using SAPbouiCOM;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Linq;
using System.Data.OleDb;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using WebDAL.Helper;

namespace General
{
    class clsPortalItems : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();
        SAPbouiCOM.Form oForm;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        SAPbouiCOM.DBDataSource oDbDataSource;
        public const string formMenuUID = "PITEMS";
        public const string formTitle = "Portal Items";
        public const string headerTable = "OITM";
        const string gridUID = "grd1";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "btLoad")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                List<clsItemEntity> itemList = CallGetItems();
                                FillGrid(oForm, itemList);
                            }
                            else if (pVal.ItemUID == "btPost")
                            {
                                //System.Threading.Thread oThread = new System.Threading.Thread(new System.Threading.ThreadStart(CreateBOQ));
                                //oThread.SetApartmentState(System.Threading.ApartmentState.STA);
                                //oThread.Start();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_ITEM")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("ItemCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {


                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID)
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
        }

        #endregion

        public void LoadForm(string menuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    oForm = objclsCommon.LoadXML(string.Empty, menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void FillGrid(SAPbouiCOM.Form oForm, List<clsItemEntity> itemList)
        {
            oForm.Freeze(true);
            try
            {
                SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
                PropertyInfo[] Properties;

                SAPbouiCOM.DataTable oDT = null;
                try
                {
                    oDT = oForm.DataSources.DataTables.Add(gridUID);
                }
                catch
                {
                    oDT = oForm.DataSources.DataTables.Item(gridUID);
                }
                try
                {
                    Properties = typeof(clsItemEntity).GetProperties();
                    foreach (PropertyInfo objProperty in Properties)
                    {
                        oDT.Columns.Add(objProperty.Name, SAPbouiCOM.BoFieldsType.ft_AlphaNumeric, 200);
                    }
                }
                catch { }
                oDT.Rows.Clear();
                Properties = typeof(clsItemEntity).GetProperties();
                 
                int j = 0;
                foreach (clsItemEntity item in itemList)
                {
                    oDT.Rows.Add();
                    for (int i = 0; i < Properties.Length; i++)
                    {
                        try
                        {
                            string name = Properties[i].Name;
                            oDT.SetValue(name, j, Properties[i].GetValue(item, null));
                        }
                        catch { }
                    }
                    j++;
                }

                oGrid.DataTable = oDT;
                for (int i = 0; i < oGrid.Columns.Count; i++)
                {
                    oGrid.Columns.Item(i).Editable = false;
                }

                SAPbouiCOM.EditTextColumn oColumns = (SAPbouiCOM.EditTextColumn)oGrid.Columns.Item("itemCd");
                oColumns.LinkedObjectType = "4";
                oApplication.StatusBar.SetText("Operation completed",BoMessageTime.bmt_Short,BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Fill Grid: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
            }
            oForm.Freeze(false);

        }


        private List<clsItemEntity> CallGetItems()
        {
            oForm = oApplication.Forms.ActiveForm;
            oApplication.StatusBar.SetText("Please wait...getting to data", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            string itemcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("ItemCode", 0).Trim();

            clsGetItemReqeustEntity _entity = new clsGetItemReqeustEntity();
            _entity.tpin = APIEntity.TPin;
            _entity.bhfId = APIEntity.BhfId;
            if (string.IsNullOrEmpty(itemcode))
            {
                _entity.lastReqDt = "20231120193115";
                return objclsCommon.GetItems(_entity);
            }
            else {
                _entity.itemCd = itemcode;
                return objclsCommon.GetItem(_entity);
            }
        }
    }
}