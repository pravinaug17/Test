using General.Classes;
using General.Extensions;
using SAPbouiCOM;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WebDAL.Helper;

namespace General
{
    class clsAPInvoice : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();
        SAPbouiCOM.Form oForm;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formMenuUID = "141";
        public const string formTitle = "A/P Invoice";
        public const string headerTable = "OPCH";
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        StringBuilder stringBuilder = new StringBuilder();
        string folderName = "SavePurchase";
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "btPush")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    if (Push() == true)
                                    {
                                        PushSaveStockMaster();
                                        PushSaveStockItems();
                                    }
                                }
                                else
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.Item oNewItem = oForm.Items.Add("btPush", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            SAPbouiCOM.Item oItem = oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel));
                            oNewItem.Left = oItem.Left + oItem.Width + 10;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            SAPbouiCOM.Button oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                            oButton.Caption = "Push";
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD
                        || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE
                        )
                    {
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        private bool Push()
        {
            oForm = oApplication.Forms.ActiveForm;
            string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();

            #region Header
            sbQuery = new StringBuilder();
            sbQuery.Append(" EXEC Proc_API_Get_Purchase '" + docEntry + "'");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());
            clsSavePurchaseEntity _entity = new clsSavePurchaseEntity();

            _entity = ConvertDatatableToList.ConvertRecordSetToEntity<clsSavePurchaseEntity>(oRs);
            _entity.tpin = APIEntity.TPin;
            _entity.bhfId = APIEntity.BhfId;
            #endregion

            #region Rows

            sbQuery = new StringBuilder();
            sbQuery.Append(" EXEC Proc_API_Get_Purchase_Rows '" + docEntry + "'");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());
            List<clsSavePurchaseItemEntity> _entityRowsList = new List<clsSavePurchaseItemEntity>();
            _entityRowsList = ConvertDatatableToList.ConvertRecordSetToList<clsSavePurchaseItemEntity>(oRs);
            #endregion

            _entity.itemList = _entityRowsList;

            return objclsCommon.PostSavePurchase(_entity, folderName);
        }

        private void PushSaveStockMaster()
        {
            oForm = oApplication.Forms.ActiveForm;
            string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();

            #region Header
            sbQuery = new StringBuilder();
            sbQuery.Append(" EXEC Proc_API_Get_Purchase_SaveStockMaster '" + docEntry + "'");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());
            clsSaveStockMasterEntity _entity = new clsSaveStockMasterEntity();

            _entity = ConvertDatatableToList.ConvertRecordSetToEntity<clsSaveStockMasterEntity>(oRs);
            _entity.tpin = APIEntity.TPin;
            _entity.bhfId = APIEntity.BhfId;

            #endregion

            #region Rows

            sbQuery = new StringBuilder();
            sbQuery.Append(" EXEC Proc_API_Get_Purchase_SaveStockMaster_Rows '" + docEntry + "'");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());
            List<clsSaveStockMasterItemEntity> _entityRowsList = new List<clsSaveStockMasterItemEntity>();
            _entityRowsList = ConvertDatatableToList.ConvertRecordSetToList<clsSaveStockMasterItemEntity>(oRs);
            #endregion

            _entity.stockItemList = _entityRowsList;

            objclsCommon.PostSaveStockMaster(_entity, folderName);
        }

        private void PushSaveStockItems()
        {
            oForm = oApplication.Forms.ActiveForm;
            string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();

            #region Header
            sbQuery = new StringBuilder();
            sbQuery.Append(" EXEC Proc_API_Get_Purchase_SaveStockItems '" + docEntry + "'");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());
            clsSaveStockItemsEntity _entity = new clsSaveStockItemsEntity();

            _entity = ConvertDatatableToList.ConvertRecordSetToEntity<clsSaveStockItemsEntity>(oRs);
            _entity.tpin = APIEntity.TPin;
            _entity.bhfId = APIEntity.BhfId;

            #endregion

            #region Rows

            sbQuery = new StringBuilder();
            sbQuery.Append(" EXEC Proc_API_Get_Purchase_SaveStockItems_Rows '" + docEntry + "'");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());
            List<clsSaveStockItemsListEntity> _entityRowsList = new List<clsSaveStockItemsListEntity>();
            _entityRowsList = ConvertDatatableToList.ConvertRecordSetToList<clsSaveStockItemsListEntity>(oRs);
            #endregion

            _entity.itemList = _entityRowsList;

            objclsCommon.PostSaveStockItems(_entity, folderName);
        }
    }
}